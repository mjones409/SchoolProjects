/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ikegame;

/**
 *
 * @author Chaos
 */
import java.util.*;
public class IkeGame {
    
 public static void main(String[] args) {
        //using try and catch to keep the program from crashing during sleep
try{// try begins
        int countDown = 10;
        int button = 0;
        // nobody counts '0' during the countdown, so terminate loop before printing it
        
        while (countDown > 0) {

             button=stdin.nextInt();
             countDown--;//timer counts down
             Thread.sleep(1000);// put the program to sleep for 1000 ms or 1s
        }
        System.out.printf("HAPPY NEW YEAR FROM MARCUS\n");
        }//ends try
        catch (Exception exception){//begins Exception exception
        
        
        }//end Exception exception
    } // end main
} // end class