/*
File:Project3.java
Author: Marcus Jones
Date: 24 Feb 2019
Purpose: week 6 project 3
 */
package project3;

import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.text.*;

public class Project3 extends JFrame{
private static final DecimalFormat df = new DecimalFormat("#");
public static double n;
private static JTextField inputBox;//input field
private static JTextField result;
private static JTextField efficiency;
static Scanner myScanner=new Scanner(System.in);
public static JFrame f = new JFrame("Project 3");
public static boolean ir=true;//iterativeRadio is true, recursiveRadio is false
private static final JLabel INPUTLABEL = new JLabel("Enter n:");
private static final JLabel RESULTLABEL = new JLabel("Result:");
private static final JLabel EFFICIENCYLABEL = new JLabel("Efficiency:");

    public static void main(String[] args) {
    //creating JFrame
    f.getContentPane().setLayout(new FlowLayout());
    f.setLocationRelativeTo(null);
     //creating buttons
    JButton compute=new JButton("                 Compute                 ");
    JRadioButton iterativeRadio = new JRadioButton("Iterative", true);
    JRadioButton recursiveRadio = new JRadioButton("Recursive          ", false);
    //creating text field
    inputBox = new JTextField("",15);
    result = new JTextField("",12);
    efficiency = new JTextField("",10);
    //adding components
    f.add(iterativeRadio);
    f.add(recursiveRadio);
    f.add(INPUTLABEL);
    f.add(inputBox); 
    f.add(compute);
    f.add(RESULTLABEL);
    f.add(result);    
    f.add(EFFICIENCYLABEL);
    f.add(efficiency);    
    efficiency.setEditable(false);
    result.setEditable(false);    
    f.setSize(250,200);
    f.setVisible(true);
        
    //closing window logic
    Write_Class write1 = new Write_Class();
    f.addWindowListener(write1);
    
    //iterative radio action listener
                    iterativeRadio.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
                            recursiveRadio.setSelected(false);
                            iterativeRadio.setSelected(true);
                            ir=true;
			}          
	      });//end iterative radio action listener
                    
                     //recursive radio action listener
                    recursiveRadio.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
                            iterativeRadio.setSelected(false);
                            recursiveRadio.setSelected(true);
                            ir=false;
			}          
	      });//end recursive radio action listener
                    
                     //compute button action listener
                    compute.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
                            //iterative selected
                            if (ir==true){
                            //get input, change to double and give value to n
                            n=Double.parseDouble(inputBox.getText());
                            result.setText(""+df.format(Sequence.computeIterative(n)));
                            efficiency.setText(""+df.format(Sequence.getEfficiency(n)));
                            }
                            
                            //recursive selected
                            if (ir==false){
                           //get input, change to double and give value to n
                            n=Double.parseDouble(inputBox.getText());
                            result.setText(""+df.format(Sequence.computeRecursive(n)));
                            efficiency.setText(""+df.format(Sequence.getEfficiency(n)));
                            }
			}         
	      });//end compute button listener
          
    }//end of main

 
    //inner class
    private static class Write_Class extends WindowAdapter {
        private Formatter x;
      @Override
      public void windowClosing(WindowEvent event){
            try
           {
                x= new Formatter("Project3Output.txt");
                fileOperations();
                x.close();
                f.setDefaultCloseOperation(EXIT_ON_CLOSE);
           }
           catch (Exception e)
           {
             System.out.println("ERROR, something went wrong");
             event.getWindow().dispose();
           }
           
      }//window event
      public void fileOperations(){
           //Creating Arrays to store efficiency scores
            String[] iterativeArray=new String[11];
            String[] recursiveArray=new String[11];
            //fill iterativeArray
            for(int i=0;i<11;i++){
            Sequence.computeIterative(i);//computing for i at i=1through10
            iterativeArray [i]=df.format(Sequence.getEfficiency(i));//filling string array with efficiency each time
            }
            //fill recursiveArray
            for(int i=0;i<11;i++){
            Sequence.computeRecursive(i);//computing for i at i=1through10
            recursiveArray [i]=df.format(Sequence.getEfficiency(i));//filling string array with efficiency each time
            }
            //formatting text document
            x.format("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n"
                    + "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s"
                    //filling text document
                    + ""," ","n0","n1","n2","n3","n4","n5","n6","n7","n8","n9","n10",
            "Iterative",
            ""+iterativeArray[0],""+iterativeArray[1],""+iterativeArray[2],""+iterativeArray[3]
            ,""+iterativeArray[4],""+iterativeArray[5],""+iterativeArray[6],""+iterativeArray[7]
            ,""+iterativeArray[8],""+iterativeArray[9],""+iterativeArray[10],"Recursive",
            ""+recursiveArray[0],""+recursiveArray[1],""+recursiveArray[2],""+recursiveArray[3]
            ,""+recursiveArray[4],""+recursiveArray[5],""+recursiveArray[6],""+recursiveArray[7],""+recursiveArray[8]
            ,""+recursiveArray[9],""+recursiveArray[10]
            );//end of format/fill
            }//end of fileOperations
          
      }//end of Write_Class
       
    }//end of Project3 class
    
   

