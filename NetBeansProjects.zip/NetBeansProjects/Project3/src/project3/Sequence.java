/*
File:Sequence.java
Author: Marcus Jones
Date: 24 Feb 2019
Purpose: week 6 project 3
 */
package project3;

public final class Sequence {

    public static double eCounter;//efficiency counter variable
    
    //computing the result iteratively
    public static double computeIterative(double n){
        eCounter=0;//reset eCounter
        double comI=n;
        double i=n;
        double a=1;
        double b=0;
       while(i>0){ 
        eCounter++;    
        comI=a+2*b;
        a=b;
        b=comI;
        i--;
       }
    return comI;
    }
    
    //computing the result recursively
    public static double computeRecursive(double n){
        eCounter=0;//reset eCounter
        
    return recursive(n);//calls private recursive method
     }
    
    //private rcursive method
    private static double recursive(double n){
    eCounter++;
    if (n<=2)
        return n;
    else
        return 2*recursive(n-1)+recursive(n-2);
    }
    
    //returns the efficiency counter
    public static double getEfficiency(double eff){
        eff=eCounter;
    return eff;
    }
    
    
}
