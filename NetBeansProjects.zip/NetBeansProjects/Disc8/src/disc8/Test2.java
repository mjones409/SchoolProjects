/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package disc8;

import java.util.ArrayList;
import java.util.Arrays;


public class Test2 {

    public static void main(String[] args){
ArrayList<Test1> a = new ArrayList<>();
ArrayList<Test1> b = new ArrayList<>();
for(int i=0;i<10;i++){
    Test1 t1=new Test1();
    a.add(t1);
}

System.out.println( Arrays.toString(a.toArray()) );
for(int i=0;i<a.size();i++){
b.add(a.get(i));
}
a.clear();

System.out.println( Arrays.toString(a.toArray()) );

System.out.println( Arrays.toString(b.toArray()) );

    }
}
