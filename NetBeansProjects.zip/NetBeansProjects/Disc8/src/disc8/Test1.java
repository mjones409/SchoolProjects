/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package disc8;


public class Test1 implements Runnable{
public static void main(String[] args){
Test1 a=new Test1();
Test1 b=new Test1();
    Thread t1=new Thread(a);
    Thread t2=new Thread(b);
    t1.start();
    t2.start();

}
    Test1(){
    
    }
    public void printMe() {
    System.out.println("printMe");
    }
    public synchronized void m1(){
    System.out.println("m1");
    }
        public synchronized void m2(){
    System.out.println("m2");
    }

    @Override
    public void run() {
        printMe();
        m1();
        printMe();
        m2();
    }

}
