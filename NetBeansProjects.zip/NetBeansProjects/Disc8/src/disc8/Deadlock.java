/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package disc8;

import java.util.concurrent.locks.*;
public class Deadlock {
static Lock snickers = new ReentrantLock();
static Lock twix = new ReentrantLock();
public static void main(String[] args){
    ABC marcus = new ABC();
    DEF vanessa = new DEF();
    Thread t1=new Thread(marcus);
    Thread t2=new Thread(vanessa);
    t1.start();
    t2.start();
}
public static class ABC implements Runnable
{
    @Override
    public void run()
    {
        try {
            snickers.lock();
            System.out.println("Marcus has snickers");
            Thread.sleep(1000);
            twix.lock();
            System.out.println("Marcus has twix");
        } catch (InterruptedException ex) {
        }
        snickers.unlock();
        twix.unlock();
    }
}
public static class DEF implements Runnable
{
    @Override
    public void run()
    {
        try {
            twix.lock();
            System.out.println("Vanessa has twix");
            Thread.sleep(1000);
            snickers.lock();
            System.out.println("Vanessa has snickers");
        } catch (InterruptedException ex) {
        }
        snickers.lock();
        twix.lock();
    }
}
}