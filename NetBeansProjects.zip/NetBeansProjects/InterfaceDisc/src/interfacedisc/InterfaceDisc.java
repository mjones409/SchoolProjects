/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfacedisc;
import java.util.Arrays;
public class InterfaceDisc {
    public static void main(String[] args) {
            //charAt(int index)
        String exampleString="abcdefghijklmnop";
        System.out.println(exampleString.charAt(7));
        
            //chars()
        int [] exArray=exampleString.chars().toArray();
        System.out.println(Arrays.toString(exArray));
        
            //codePoints()
        int [] exArray2=exampleString.codePoints().toArray();
        System.out.println(Arrays.toString(exArray2));

            //length()
        System.out.println(exampleString.length());
        
            //subSequence(int start, int end)
        System.out.println(exampleString.subSequence(1, 7));
        
            //toString
            System.out.println(exampleString.toString());
    }
}
