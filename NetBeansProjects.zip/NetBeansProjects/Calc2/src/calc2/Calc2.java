/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calc2;


import java.math.BigDecimal;
import java.math.RoundingMode;
import java.lang.*;

public class Calc2 {

static double i=2;
static double n=0;
static double v=0;
static double a=4;
static double b=5;

static BigDecimal four=new BigDecimal("4");
static BigDecimal five=new BigDecimal("5");
static BigDecimal bd=new BigDecimal("1");



    public static void main(String[] args) {
        a=a/5;
        System.out.println(a);
        //System.out.println((1/(Math.pow(135,140))));
        //Alternate();
        //a1();
        //a3();
        //a4();
        //b4();
        b5();
    }
    static void Alternate(){
        while(i<999){
            
        v=Math.pow(v,(a))*2;
        System.out.println("vanilla: "+i+"    "+v);
        //n=Math.pow((n+4)/(n+5), n);
        //System.out.println("power: "+i+"    "+n+"\n");
        i++;
        }
    
    }
    static void a1(){
        while(i<71999){
            
        
        //a=Math.pow(i+4, i);
        //b=Math.pow(i+5, i);
        //v=a;
        //System.out.println("vanil: "+i+"    "+v);
        
        n=Math.sqrt(Math.pow(n, 4)+5*Math.pow(n, 2)+1)-n;
        System.out.println("power: "+i+"    "+n+"\n");
        i++;
        v=i;
        n=i;
        }
    }
    
       static void a3(){
        while(i<99999){
            
        v=Math.pow(a,(i));
        //n=Math.pow((n+4)/(n+5), n);
        //System.out.println("power: "+i+"    "+n+"\n");
        n=n+v;
        System.out.println("vanilla: "+i+"    "+n);
        i++;
        }
    
    }
        static void a4(){
        while(i<1730){
            
        v=3/(i*(i+3));
        n=n+v;
        System.out.println("vanilla: "+i+"    "+n+"   <--------------     "+v);
        i++;
        }
    
    }
        
        static void b4(){
        while(i<30){
            
        v=Math.atan(i);
        n=n+v;
        System.out.println("vanilla: "+i+"    "+n+"    "+v);
        i++;
        }
    
    }
static void b5(){
        while(i<30){
            
        v=1/(i*Math.pow(Math.log(i),(3)));
        //v=Math.pow(v,(3));
       // v=Math.pow(v,(3));
        n=n+v;
        System.out.println("vanilla: "+i+"    "+n+"    "+v);
        i++;
        }
    
    }    
}
