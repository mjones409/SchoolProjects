
package justin;

public class Justin {

    public static void main(String[] args) {
        boolean r=true;
         r=false;
        double bon=77.52;
        bon=bon*2;
        char king;
        king='y';
        System.out.println("Hello World"+bon);
         System.out.println("Happy Birthday"+king+king+king+king);
   String diana;
   diana="";
   bon=1;
   int a=1;
   while(diana==""){System.out.println("Hello World"+bon);
   bon=bon+1;
   if(bon==1000000){
   diana="apples";
   
   
   }
   
   }
    }
    
}
