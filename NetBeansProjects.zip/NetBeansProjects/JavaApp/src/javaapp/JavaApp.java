
package javaapp;


import java.util.Random;

public class JavaApp {

    // Main method

    public static void main(String[] args) { 

        // x and y command line arguments

        int x = Integer.parseInt(args[0]);

        int y = Integer.parseInt(args[1]);   

    

        Random random = new Random();   

        System.out.println(x+ " Random Integer between 0 and " + y + " include: ");   

         
        //Printing out the the random integer  
        for(int i =0; i< x ; i++)      

  {   

            int randomNumbers = random.nextInt(y);   

            System.out.println(randomNumbers);

   

        }

    }

}