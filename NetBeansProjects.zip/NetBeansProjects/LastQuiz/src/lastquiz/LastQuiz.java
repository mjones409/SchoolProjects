/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lastquiz;

/**
 *
 * @author Chaos
 */
public class LastQuiz {

    /**
     * @param args the command line arguments
     */
    static int a;
    public static void main(String[] args) {
        //int n=0;
        //System.out.println(n % 10);
        //a=recurse(6);
        //factorial(5);
        //System.out.println(a);
        System.out.println(countDown(2, 0));        

    }
    public static int recurse(int n)
{
   if (n <= 1)
       return 1;
   else
       return n + recurse(n - 2);
}
    public static long factorial(int n)
{
   if (n == 0)
       return 1;
   else
       return n*factorial(n-1);
}
    
    public static int countDown(int n, int result)
   {
       if (n == 0)
           return 0;
       else
           return countDown(n - 1, n + result);
   }
    
}
