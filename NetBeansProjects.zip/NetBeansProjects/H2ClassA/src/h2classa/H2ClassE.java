/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h2classa;
  public class H2ClassE {
public static final double myNumber = 17.36;
int x, y, z;
 
    H2ClassE (int a) {
      this (5, 12);
      x = a;
    }
 
    H2ClassE (int b, int c) {
     y = b;
     z = c;
   }
 } // end class H2ClassE

