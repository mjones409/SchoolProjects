/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h2classa;

public class H2ClassG {
   final int x;
   H2ClassG () {x=0;}
   H2ClassG (int a) {x = a;}
 } // end class H2ClassG
