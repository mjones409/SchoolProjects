/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h2classa;

import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.WindowConstants;

public class Week4Discussion 
{
private void mainWindow() 
{
JFrame window = new JFrame("Donut Orders"); 
JPanel mainPanel = new JPanel();
JPanel input = new JPanel();
JPanel process = new JPanel();
JPanel choicePanels = new JPanel();
JPanel radioSelect = new JPanel();
JPanel quantityPanel = new JPanel();

JLabel inputLabel = new JLabel("Customer Name");
JTextField inputTxt = new JTextField(null,20);
JButton processBttn = new JButton("Place order");
JRadioButton chocRBttn = new JRadioButton("Chocolate Glaze");
JRadioButton appRBttn = new JRadioButton("Apple Pie");
JRadioButton bostRBttn = new JRadioButton("Boston Creme");
JRadioButton pumpRBttn = new JRadioButton("Pumpkin Spice");
JRadioButton blueRBttn = new JRadioButton("Blueberry Glaze");
JRadioButton mixRBttn = new JRadioButton("Mixed Selection");
JCheckBox sixBox = new JCheckBox("Half a Dozen");
JCheckBox twelveBox = new JCheckBox("One Dozen");

mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
choicePanels.setLayout(new GridLayout());
radioSelect.setLayout(new BoxLayout(radioSelect, BoxLayout.Y_AXIS));
quantityPanel.setLayout(new BoxLayout(quantityPanel, BoxLayout.Y_AXIS));

input.add(inputLabel);
input.add(inputTxt);
process.add(processBttn);
radioSelect.setBorder(BorderFactory.createTitledBorder("Selection"));
radioSelect.add(chocRBttn);
radioSelect.add(appRBttn);
radioSelect.add(bostRBttn);
radioSelect.add(pumpRBttn);
radioSelect.add(blueRBttn);
radioSelect.add(mixRBttn);
quantityPanel.setBorder(BorderFactory.createTitledBorder("Quantity"));
quantityPanel.add(sixBox);
quantityPanel.add(twelveBox);
ButtonGroup radioSelectGroup = new ButtonGroup();
radioSelectGroup.add(chocRBttn);
radioSelectGroup.add(appRBttn);
radioSelectGroup.add(bostRBttn);
radioSelectGroup.add(pumpRBttn);
radioSelectGroup.add(blueRBttn);
radioSelectGroup.add(mixRBttn);
ButtonGroup quantitySelect = new ButtonGroup();
quantitySelect.add(sixBox);
quantitySelect.add(twelveBox);
chocRBttn.setSelected(true);
choicePanels.setPreferredSize(new Dimension(450, 350));
choicePanels.add(radioSelect);
choicePanels.add(quantityPanel);

mainPanel.add(input);
mainPanel.add(choicePanels);
mainPanel.add(process);
window.add(mainPanel);
window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
window.setSize(400,300);
window.setLocationRelativeTo(null);
window.setVisible(true);
}
public static void main(String[] args) 
{
Week4Discussion begin = new Week4Discussion();
begin.mainWindow();
}
}