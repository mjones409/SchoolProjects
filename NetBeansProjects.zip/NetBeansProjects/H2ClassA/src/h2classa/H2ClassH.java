/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h2classa;

 public class H2ClassH {
   int x;
 
   int H2ClassH (int a) {
       x=a;
     if (x == 7) return 1;
     return 2;
   } // end
 } // end class H2ClassH
