/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h2classa;

  import javax.swing.*;
  import java.awt.event.*;
 
  public class H2ClassJ extends MouseAdapter {
    public static final long serialVersionUID = 22;
 
    @Override
             public void mouseClicked (MouseEvent e) {}
     

 
 } // end class H2ClassJ
