/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h2classa;

  import java.util.ArrayList;
 
  public class H2ClassA {
    ArrayList <H2ClassB> list = new ArrayList <H2ClassB> ();
 
    public static void main (String args []) {
      H2ClassA y = new H2ClassA ();
      int [] v = {4, 3, 7, 5, 99, 3};
      for (int m: v) 
       y.list.add (new H2ClassB (m));
     System.out.println (y.toString());// calls toString on obj y
   } // end main
    @Override
 public String toString(){
     String output="";
     for(int i = 0; i < list.size(); i++)//iterates through list
{
    output=output+" "+list.get(i).toString();//calls toString on each list obj
}
     
   return ""+output;
   }//end toString
 
 } // end class H2ClassA
 
 class H2ClassB {
   int x;
   H2ClassB (int a) { 
       x = a;
   }
   @Override
   public String toString(){
   return ""+x;//toString returns x as a string
   }
 } // end H2ClassB
