/* File: HappyNewYear.java

 * Author: Marcus Jones

 * Date: 09-27-2018

 * Purpose: This program is designed to partake 
 * in the New Years countdown with the user

 */
import java.util.*;
public class HappyNewYear {

    public static void main(String[] args) {
        //using try and catch to keep the program from crashing during sleep
try{// try begins
        int countDown = 10;

        // nobody counts '0' during the countdown, so terminate loop before printing it

        while (countDown > 0) {

            System.out.printf("%d!\n", countDown);
             countDown--;//timer counts down
             Thread.sleep(1000);// put the program to sleep for 1000 ms or 1s
        }
        System.out.printf("HAPPY NEW YEAR FROM MARCUS\n");
        }//ends try
        catch (Exception exception){//begins Exception exception
        
        
        }//end Exception exception
    } // end main
} // end class