/*
 * File: DGraph.java
 * Author: Marcus Jones
 * Date: 11 Aug 2019
 * Purpose: CMSC 350 Project 4
 */
package p4gui;

import java.util.*;
import p4gui.P4GUI.*;

public class DGraph<T> {

    private ArrayList<LinkedList<Integer>> adjacency;//arraylist that stores linkedlists that stores integers
    private HashMap<T, Integer> mapTtoInteger;//T is the key and integer is the value
    private HashMap<Integer, T> mapIntegertoT;//same as above, but flipped

    private int counter;//used in addVertex

//constructor
    public <T> DGraph() {

        adjacency = new ArrayList<>();
        mapTtoInteger = new HashMap<>();
        mapIntegertoT = new HashMap<>();
        counter = 0;
    }

    //adds each unique vertex to hashmaps paired with its index (counter)
    public void addVertex(T vertex) {

        if (mapTtoInteger.containsKey(vertex) == false) {//checks to see if inputted vertex is unique
            mapTtoInteger.put(vertex, counter);//stores the vertex as a key and the counter as the value
            mapIntegertoT.put(counter, vertex);//"                     "value"                     "key
            counter++;//increases the counter
        }

    }

//adds each integer that corresponds to classes being pointed to to a linked list that falls under the index of the class doing the pointing
    public void addEdge(T vertexFrom, T vertexTo) {
        LinkedList<Integer> vList = new LinkedList<>();
        //vList is filled with all the elements in adjacency under the index of vertexFrom
        vList.addAll(adjacency.get((mapTtoInteger.get(vertexFrom))));
        //adds the integer form of vertexTo to vList
        vList.add(mapTtoInteger.get(vertexTo));
        //places vList in the index of vertexFrom
        adjacency.set(mapTtoInteger.get(vertexFrom), vList);
    }

    public String topOrdGeneration(T startVertex) throws CycleException, InvalidClassException {
        //checks for InvalidClassException
        if (mapTtoInteger.containsKey(startVertex) == false) {
            throw new InvalidClassException();
        }

        //checks for cycles by first making a deep copy of the arraylist
        ArrayList<LinkedList<Integer>> tempAdj = new ArrayList<>();
        Iterator<LinkedList<Integer>> iterator3 = adjacency.iterator();
        while (iterator3.hasNext()) {
            tempAdj.add((LinkedList<Integer>) iterator3.next().clone());
        }

        /*each element of tempAdj will now contain
        all of its direct as well as INDIRECT dependencies*/
        for (int i = 0; i < tempAdj.size(); i++) {
            for (int j = 0; j < tempAdj.get(i).size(); j++) {
                LinkedList<Integer> cycleList = new LinkedList<>();
                cycleList.addAll(tempAdj.get(tempAdj.get(i).get(j)));
                tempAdj.get(i).addAll(cycleList);

                /* if an element depends on itself, it is 
        cyclic so we need to break out of this loop manually */
                if (tempAdj.get(i).contains(i)) {
                    break;
                }
            }
        }

        /* if the startVertex directly or INDIRECTLY relies on intself, 
         the selected portion of the digraph cannot compile because it is cyclic*/
        if (tempAdj.get(mapTtoInteger.get(startVertex)).contains(mapTtoInteger.get(startVertex))) {
            throw new CycleException();
        }

        //in tempAdj, the list whose index corresponds to startVertex is copied to copyList
        LinkedList copyList = (LinkedList) tempAdj.get(mapTtoInteger.get(startVertex)).clone();
        //outList will eventually contain the values that will be outputted to the user
        LinkedList<String> outList = new LinkedList<>();

        //while loop to iterate through copylist
        while (copyList.isEmpty() == false) {
            //if the last value in copyList is already in outList, just pops the last value in copyList
            if (outList.contains("" + mapIntegertoT.get(copyList.peekLast()))) {
                copyList.pollLast();
                //if the last value in copyList is not in outList, add it to outList
            } else {
                outList.add("" + mapIntegertoT.get(copyList.pollLast()));
            }
        }
        //adds the starting vertex to the outList
        outList.addLast("" + mapIntegertoT.get(mapTtoInteger.get(startVertex)));
        String out1 = "";//this will be the String returned to the user
        //out1 becomes the reverse of outList
        while (outList.isEmpty() == false) {
            out1 = out1 + outList.pollLast() + " ";
        }
        return out1;//returns the order classes need to be compiled to the user starting from startVertex
    }

//fills the whole arraylist with empty linkedlists
    public void fillAdjacency() {
        LinkedList<Integer> tempIList = new LinkedList<>();

        for (int i = 0; mapTtoInteger.containsValue(i); i++) {
            adjacency.add(tempIList);
        }
    }

}
