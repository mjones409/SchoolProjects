/*
 * File: P4GUI.java
 * Author: Marcus Jones
 * Date: 11 Aug 2019
 * Purpose: CMSC 350 Project 4
 */
package p4gui;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class P4GUI extends JFrame {

    private static DGraph dg;
    private static JTextField inputFileBox;//input file name
    private static JTextField cToRecompileBox;//class to recompile
    private static JTextField RecomOrderBox;//recompilation order
    public static JFrame f = new JFrame("Class Dependency Graph");
    //JLABELS
    private static final JLabel INPUTFILELABEL = new JLabel("Input file name:");
    private static final JLabel CRECOMPILELABEL = new JLabel("Class to recompile:");
    private static final JLabel RECOMORDERLABEL = new JLabel("Recompilation Order");

    public static void main(String[] args) {
        //creating JFrame
        f.getContentPane().setLayout(new FlowLayout());
        //creating buttons
        JButton buildDG = new JButton("Build Directed Graph");
        JButton topolOrder = new JButton("Topological Order");
        //creating text field
        inputFileBox = new JTextField("", 20);
        cToRecompileBox = new JTextField("", 20);
        RecomOrderBox = new JTextField("", 56);
        //adding components
        f.add(INPUTFILELABEL);
        f.getContentPane().add(inputFileBox);
        f.add(buildDG);
        f.add(CRECOMPILELABEL);
        f.getContentPane().add(cToRecompileBox);
        f.add(topolOrder);
        f.add(RECOMORDERLABEL);
        f.getContentPane().add(RecomOrderBox);

        RecomOrderBox.setEditable(false);
        //misc Jframe stuff
        f.setSize(590, 250);
        f.setVisible(true);
        f.setResizable(false);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Build Directed Graph button action listener
        buildDG.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                String fromFile = "";
                //assigning fromFile the value of the contents of the .txt file
                try {
                    Scanner myScanner = new Scanner(new File(inputFileBox.getText()));
                    while (myScanner.hasNext()) {
                        //adding a ~ to break up each line
                        fromFile = fromFile + myScanner.nextLine() + "~";
                    }
                    //deleting the last ~
                    if (fromFile.contains("~")) {
                        fromFile = fromFile.substring(0, fromFile.length() - 1);
                    }
                    buildDGraphFromFile(fromFile);//calls method below
                    RecomOrderBox.setText("");
                    cToRecompileBox.setText("");
                    JOptionPane.showMessageDialog(f, "SUCCESS\nGraph Built Successfully");
                } catch (FileNotFoundException e) {
                    RecomOrderBox.setText("");
                    JOptionPane.showMessageDialog(f, "ERROR\nFile Did Not Open");
                }
            }

        });//end Build Directed Graph button listener

        //Topological Order button action listener
        topolOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg1) {
                try {
                    try {
                        //calls topOrdGeneration passing the user input to the method
                        RecomOrderBox.setText(dg.topOrdGeneration(cToRecompileBox.getText()));
                    } catch (InvalidClassException ice) {
                        RecomOrderBox.setText("");
                        JOptionPane.showMessageDialog(f, ice.getMessage());
                    }
                } catch (CycleException ce) {
                    RecomOrderBox.setText("");
                    JOptionPane.showMessageDialog(f, ce.getMessage());
                }
            }

        });//end Topological Order button listener

    }

    public static void buildDGraphFromFile(String fromFile) {
        dg = new DGraph();
        //when adding the vertexes, it is not necessary to split the input by line
        String splitS = fromFile.replace('~', ' ');
        String[] vArray = splitS.split(" ");
        //adds each vertex one by one
        for (int i = 0; i < vArray.length; i++) {
            dg.addVertex(vArray[i]);
        }

        dg.fillAdjacency();//fills adjacency

        //creates an array containing each line of text from the file
        String[] relationArray = fromFile.split("~");
        //iterates through each relation
        for (int i = 0; i < relationArray.length; i++) {
            //splits each relation into vertexes
            vArray = relationArray[i].split(" ");
            //iterates through each vertex adding edges from 
            //the first class to each following class
            for (int j = 1; j < vArray.length; j++) {
                dg.addEdge(vArray[0], vArray[j]);
            }

        }

    }

    public static class CycleException extends Exception {

        // Overrides Exception's getMessage()
        @Override
        public String getMessage() {
            return "ERROR\nCycle Detected\n(try choosing a different class or file)";
        }

    }

    public static class InvalidClassException extends Exception {

        // Overrides Exception's getMessage()
        @Override
        public String getMessage() {
            return "ERROR\nInvalid Class Name";
        }

    }
}
