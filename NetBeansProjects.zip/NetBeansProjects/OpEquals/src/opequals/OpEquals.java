/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opequals;

/**
 *
 * @author Chaos
 */
public class OpEquals {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
int a=1;
int b=2;
int c=3;

a+=5;
b*=4;
c+=a*b;
System.out.println("c "+c);    
    
c%=6;
System.out.println("a "+a);
System.out.println("b "+b);
System.out.println("c "+c);
System.out.print("rando: ");
for(int i=0; i<12; i++){
int rando= (int)(Math.random()*100);
System.out.print(""+rando+" , ");
    }
    }
    
}
