/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package messaround;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author Chaos
 */
public class MessAround {

   
    static LinkedList<String> stack = new LinkedList<>();
    
    public static void main(String[] args) {
        int i=1;
        while(i<26){
        stack.add(""+i);
        i++;
        }
        System.out.println(stack);
        stack.removeLast();
        stack.add("example");
        stack.removeLast();
        stack.removeLast();
        stack.add("example 2");
        System.out.println(stack);    
    }
    
}
