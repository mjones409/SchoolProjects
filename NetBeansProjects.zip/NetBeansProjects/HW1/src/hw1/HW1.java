/* 
File: HW1.java
Author: Marcus Jones
Date: 30 August 2019
Purpose: CMSC325 HW1
 */
package hw1;

import javax.swing.JFrame;

public class HW1 extends JFrame {

    public HW1() {

        // Construct Class with Graphics Component
        Caterpillar2D myExample = new Caterpillar2D();
        // Add to JFrame
        add(myExample);
        // Set the Default Size and title
        setSize(600, 300);
        setTitle("CMSC 325 Homework 1");

        // Frame Default to be able to closd
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Center the Frame
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {

        HW1 myDriver = new HW1();
        myDriver.setVisible(true);

    }
}
