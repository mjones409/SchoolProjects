/* 
File: Caterpillar2D.java
Author: Marcus Jones
Date: 30 August 2019
Purpose: CMSC325 HW1
 */
package hw1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Line2D;
import javax.swing.JPanel;

public class Caterpillar2D extends JPanel {

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Call methods to draw
        drawCircle(g, Color.RED, 50, 50, 90);//head
        drawCircle(g, Color.ORANGE, 140, 60, 90);//neck
        drawCircle(g, Color.BLACK, 230, 65, 90);//middle body
        drawCircle(g, Color.GREEN, 320, 68, 90);//section 4
        drawCircle(g, Color.BLUE, 410, 68, 90);//caboose
        drawLine(g, Color.BLACK, 190, 150, 190, 200);//neck leg
        drawLine(g, Color.BLACK, 280, 155, 280, 200);//mid leg
        drawLine(g, Color.BLACK, 370, 157, 370, 200);//sec4 leg
        drawLine(g, Color.BLACK, 460, 157, 460, 200);//caboose leg
        drawRect(g, Color.BLACK, 65, 70, 10, 20);//caterpillar's right eye
        drawRect(g, Color.BLACK, 85, 70, 10, 20);//caterpillar's left eye
        drawEllipse(g, Color.CYAN, 60, 110, 35, 10);//caterpillar's mouth
    }

    // Method to draw an Ellipse
    private void drawEllipse(Graphics g, Color c, int x, int y, double w, double h) {

        Graphics2D g2d = (Graphics2D) g;
        Ellipse2D e = new Ellipse2D.Double(x, y, w, h);
        g2d.setColor(c);
        g2d.draw(e);
    }

    // Method to draw a Line
    private void drawLine(Graphics g, Color c, int x1, int y1, int x2, int y2) {

        Graphics2D g2d = (Graphics2D) g;
        Line2D myLine = new Line2D.Double(x1, y1, x2, y2);
        g2d.setColor(c);
        g2d.draw(myLine);
    }

    // Method to draw a Circle
    private void drawCircle(Graphics g, Color c, int x, int y, double wh) {

        Graphics2D g2d = (Graphics2D) g;
        Ellipse2D myCircle = new Ellipse2D.Double(x, y, wh, wh);
        g2d.setColor(c);
        g2d.draw(myCircle);
    }

    // Method to draw a Rectangle
    private void drawRect(Graphics g, Color c, int x, int y, int w, int h) {

        Graphics2D g2d = (Graphics2D) g;
        Rectangle2D myRect = new Rectangle2D.Double(x, y, w, h);
        g2d.setColor(c);
        g2d.draw(myRect);
    }

}
