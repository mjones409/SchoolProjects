/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myclassa;

   public class MyClassE {
     public static void main (String args []) {
       MyClassF m = new MyClassF (83);
       System.out.println(m.v);
     } // end main
   } // end class MyClassE
 
   class MyClassF {
     int v = 12;
 
     MyClassF (int pV) {
      v = pV;
    } 
 
  } // end class MyClassF
