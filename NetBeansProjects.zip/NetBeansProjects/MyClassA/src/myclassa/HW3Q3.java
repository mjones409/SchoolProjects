/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myclassa;

import java.awt.*;
import javax.swing.*;


public class HW3Q3 {
     public static void main(String[] args) {
        //creating all the panels and jframe
        JFrame frame = new JFrame("layouts");
        JButton a=new JButton("a");
        JButton b=new JButton("b");
        JButton c=new JButton("c");
        JButton d=new JButton("d");
        JButton e=new JButton("e");
        JButton f=new JButton("f");
        FlowLayout flow = new FlowLayout();
        GridLayout grid = new GridLayout(3,2,10,2);   
        BorderLayout border= new BorderLayout();
        GridBagConstraints gbc=new GridBagConstraints();
        
        frame.setLayout(null);
        
        Insets insets = frame.getInsets();
        Dimension size = a.getPreferredSize();
        a.setBounds(200 + insets.left, 5 + insets.top,
             size.width, size.height);
        
        size = b.getPreferredSize();
        b.setBounds(100 + insets.left, 10 + insets.top,
             size.width, size.height);
        
        size = c.getPreferredSize();
        c.setBounds(0 + insets.left, 0 + insets.top,
             size.width, size.height);
        
        frame.add(a);
        frame.add(b);
        frame.add(c);
        frame.add(d);
        frame.add(e);
        frame.add(f);
//        gbc.anchor=GridBagConstraints.NORTHWEST;
//        gbc.gridx=0;
//        gbc.gridy=0;
//        frame.setLayout(new GridBagLayout());
//        frame.add(a,gbc);
//        gbc.gridy=1;
//        frame.add(b,gbc);
//        gbc.gridy=2;
//        frame.add(c,gbc);
//        gbc.gridy=0;
//        gbc.gridx=1;
//        frame.add(d,gbc);
//        gbc.gridy=1;
//        frame.add(e,gbc);
//        gbc.gridy=2;
//        frame.add(f,gbc);
//        frame.add(a, border.CENTER);
//        frame.add(b, border.NORTH);
//        frame.add(c, border.SOUTH);
//        frame.add(d, border.WEST);
//        frame.add(e, border.EAST);
        frame.setSize(250,250);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        

     }
}
