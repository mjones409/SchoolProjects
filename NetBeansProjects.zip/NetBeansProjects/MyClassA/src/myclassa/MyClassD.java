/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myclassa;

   public class MyClassD {
     public static void main (String args []) {
       MyClassC m = new MyClassC (23);
       System.out.println(m.v);
     } // end main
   } // end class MyClassD
 
   class MyClassC {
     int v = 12;
 
    public MyClassC (int pV) {
     int v = pV;
    } 
 
  } // end class MyClassC
