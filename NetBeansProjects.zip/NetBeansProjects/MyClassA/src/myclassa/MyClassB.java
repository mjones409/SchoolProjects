/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myclassa;

   public class MyClassB { 
    int v = 12;
 
    public void MyClassB (int pV) {
      v = pV;
    } 
 
    public static void main (String args []) {
      MyClassB m = new MyClassB ();
      m.MyClassB(23);
      System.out.println(m.v);
   } // end main
 } // end class MyClassB
