/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myclassa;

  public class MyClassG {
    public static void main (String args []) {
      MyClassH m = new MyClassH (23, true);
       System.out.println(m.v);
    } // end main
  } // end class MyClassG
 
  class MyClassH {
    int v = 12;
 
   public MyClassH (int x, boolean b) {
     this (x);
    
   } 
 
   private MyClassH (int pV) {
     v = pV;
   } 
 
 } // end class MyClassH
