/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cmsc451hw3;

import java.util.Arrays;

public class CMSC451hw3 {

    public static void main(String[] args) {
      //int [] array={1,2,3,4,5};
      int [] array={5,4,3,2,1};
      insertionSort(array);
    }
    
    public static void insertionSort(int array[]) 
    { 
        System.out.println("insertionSort ");
        insert(array, 1); 
    } 
    public static void insert(int[] array, int i) 
    { 
        System.out.println("insert "+i);
        if (i < array.length) 
        { 
            int value = array[i];
            int j = shift(array, value, i); 
            array[j] = value; insert(array, i + 1); 
        } 
        System.out.println(Arrays.toString(array));
    }
    public static int shift(int[] array, int value, int i) 
    { 
        System.out.println("shift "+i);
        int insert = i; 
        if (i > 0 && array[i - 1] > value)
        {
            array[i] = array[i - 1]; 
            insert = shift(array, value, i - 1);
        } 
        return insert; 
    }
}
