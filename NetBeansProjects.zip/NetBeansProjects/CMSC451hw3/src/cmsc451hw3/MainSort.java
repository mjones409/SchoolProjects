package cmsc451hw3;
import java.util.*;
public class MainSort {
    public static void main(String[] args) {
        int[] array = {5,1,2,3,4};
        SortedPriorityQueue<Integer> theQue = new SortedPriorityQueue<>();
        sort(array);
        System.out.println("");
        javaSort(array);
    }
    public static void sort(int[] array) {
        SortedPriorityQueue<Integer> queue = new SortedPriorityQueue();
        for (int i = 0; i < array.length; i++) {
            queue.add(array[i]);
        }
        for (int i = 0; i < array.length; i++) {
            array[i] = queue.remove();
        }
    }
    public static void javaSort(int[] array) {
        ///////Java sorting
        PriorityQueue<Integer> pQue = new PriorityQueue<>();
        for (int i = 0; i < array.length; i++) {
            pQue.add(array[i]);
        }
        while (!pQue.isEmpty()) {
            System.out.print(pQue.remove() + ",");
        }
        //////Java sorting
    }
}
