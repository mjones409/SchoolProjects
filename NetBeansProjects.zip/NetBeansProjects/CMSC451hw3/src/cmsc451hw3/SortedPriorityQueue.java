package cmsc451hw3;
import java.util.*;
public class SortedPriorityQueue<T extends Comparable> {
//arraylist
    private ArrayList<T> queue = new ArrayList();
//add method
    public void add(T element) {
//checks if queue is empty or the element is largest
        if (queue.isEmpty() || queue.get(queue.size() - 1).compareTo(element) <= 0) {
//add element
            queue.add(element);
//if the queue is not empty and we don't have largest element
        } else {
//iterate through arraylist
            for (int i = 0; i < queue.size(); i++) {
                System.out.println(element);
//if the element is smaller than i
                if (element.compareTo(queue.get(i)) < 0) {
//add element at that place
                    queue.add(i, element);
//ends the loop
                    break;
                }
            }
        }
    }
    public T remove() {
        System.out.print(queue.get(0) + ",");
        return queue.remove(0);
    }
}
