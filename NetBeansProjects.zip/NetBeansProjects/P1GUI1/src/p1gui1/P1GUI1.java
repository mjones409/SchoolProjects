/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1gui1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Chaos
 */
public class P1GUI1 {

    
    
    
    static String userString= "4+5";
    static ArrayList<String>operatorStack1=new ArrayList<>();
    static ArrayList<String>operandStack2=new ArrayList<>();
    static ArrayList<String> masterStack3 = new ArrayList<>();  


    

    
   public void evaluate(){
        
     //operatorStack1.add("(");
       userString=userString.replaceAll("\\s+","");//delete all spaces
       StringBuilder sb=new StringBuilder(userString);//create stringbuilder object
       

       //puts comma between all tokens
       for(int i=0;i<sb.length();i++){
       if(sb.charAt(i)=='/'||sb.charAt(i)=='*'||sb.charAt(i)=='+'||sb.charAt(i)=='-'||sb.charAt(i)==')'||sb.charAt(i)=='('){
    
       sb.insert(i, ',');
       sb.insert(i+2, ',');
       i++;
      }
       }
       
       //deletes extra commas
        for(int i=0;i<sb.length()-1;i++){
        if (sb.charAt(i)==','&&sb.charAt(i+1)==','){
        sb.deleteCharAt(i);
        i++;
        }
        }
       
       //deletes extra commas if they appear in the front or back of the string
       if (sb.charAt(0)==','){
       sb.deleteCharAt(0);
       }
       if (sb.charAt(sb.length()-1)==','){
       sb.deleteCharAt(sb.length()-1);
       }
       
       System.out.println("String: "+sb);
       userString=sb.toString();//gives userString the same value as sb
       
       
       
    pushPopMagic();
   }
   public static void performCalc(){
       
      }
   
    public static void push(String token){
      
        
    }
   public static void pushPopMagic(){
       String[] tempArray = userString.split(",");
       masterStack3.addAll(Arrays.asList(tempArray));
       System.out.println("master stack:  "+masterStack3);
        System.out.println("operator stack:  "+operatorStack1);
       System.out.println("operand stack:  "+operandStack2);
       
       for(int i=0;i<masterStack3.size();i++){//iterate through masterStack3
       
            try{//check if number
        int numOrNot=Integer.parseInt(masterStack3.get(i));   
        operandStack2.add(masterStack3.get(i));
           System.out.println("TRYCOMPLETE LINE94");
                      System.out.println("num stack:"+operandStack2);

       }
       catch(NumberFormatException notAnumber){
                   System.out.println("ERROR, NOT A NUMBER!(numOrNot)");

       }//end of catch
            
       //check if left parenthesis
        if(masterStack3.get(i).equals("(")){
               operatorStack1.add(masterStack3.get(i));
               }
        
        //check if right parenthesis
        else if(masterStack3.get(i).equals(")")){
            
        while(operatorStack1.get(i).equals("(")==false){
            String op=operatorStack1.get(operatorStack1.size()-1);
       int value2=Integer.parseInt(operandStack2.get(operandStack2.size()-1));
       operandStack2.remove(operandStack2.size()-1);
       int value1=Integer.parseInt(operandStack2.get(operandStack2.size()-1));
       operandStack2.remove(operandStack2.size()-1);
       
       String newValue;
       switch(op){
           case "+": newValue=""+(value1+value2); 
           case "-":newValue=""+(value1-value2);
           case "*":newValue=""+(value1*value2);
           case "/":newValue=""+(value1/value2);
           
           operandStack2.add(newValue);
       }//end switch
       }//end while loop
        }// end right parenthesis check
        
            
       }//end of masterStack3 iterations
      
       
       }
        
   
}
   
 //while(moreTokens) {
       while(masterStack3.isEmpty()==false){
           System.out.println("masterstack empty LINE87");
       //if token is not an operator(in other words, it is a number)
       //operandStack.push(token)
       try{
        int numOrNot=Integer.parseInt(masterStack3.get(0));   
        operandStack2.add(masterStack3.get(0));
        masterStack3.remove(0);
           System.out.println("TRYCOMPLETE LINE94");
                      System.out.println("num stack:"+operandStack2);

       }
       catch(NumberFormatException notAnumber){
                   System.out.println("ERROR, NOT A NUMBER!(numOrNot)");

       }
//else if token is "("
//operatorStack.push(symbol) // This creates a false 
// bottom to the stack.
// It must be matched by
// a ")" 
       if(masterStack3.get(0).equals("(")){
                      System.out.println(" LINE 106");

       operatorStack1.add(masterStack3.get(0));
       masterStack3.remove(0);
       }
      // else if token is ")"     
// Process all the operators until a matching "(" 
// is found.   
       else if (masterStack3.get(0).equals(")"))
       while(operatorStack1.get(operatorStack1.size()-1).equals("(")==false){
                      System.out.println("while loop LINE116");

           masterStack3.remove(0);
           String op=operatorStack1.get(operatorStack1.size()-1);
       int value2=Integer.parseInt(operandStack2.get(operandStack2.size()-1));
       operandStack2.remove(operandStack2.size()-1);
       int value1=Integer.parseInt(operandStack2.get(operandStack2.size()-1));
       operandStack2.remove(operandStack2.size()-1);
       
       String newValue;
       switch(op){
           case "+": newValue=""+(value1+value2); 
           case "-":newValue=""+(value1-value2);
           case "*":newValue=""+(value1*value2);
           case "/":newValue=""+(value1/value2);
           
           operandStack2.add(newValue);
       
       }
       
       }
       
       else// token is +, -,*, /
           //while(true){
                          System.out.println("while loop LINE140");
                                      System.out.println(operatorStack1+"   opstack LINE141");

               while ((operatorStack1.isEmpty()||operatorStack1.get(operatorStack1.size()-1).equals("("))||((operatorStack1.get(operatorStack1.size()-1).equals("-")||operatorStack1.get(operatorStack1.size()-1).equals("+"))
                       &&masterStack3.get(0).equals("*")||masterStack3.get(0).equals("/"))
                       ){
                  
                   operatorStack1.add(masterStack3.get(0));
                   masterStack3.remove(0);
                                      System.out.println(masterStack3+"     iosdfaiewjwpjeio");

           //}
             
           }
       // Process the operator as earlier.
                  System.out.println("process request LINE152");
System.out.println("master stack:  "+masterStack3);
        System.out.println("operator stack:  "+operatorStack1);
       System.out.println("operand stack:  "+operandStack2);
       
          String op=operatorStack1.get(operatorStack1.size()-1);
       int value2=Integer.parseInt(operandStack2.get(operandStack2.size()-1));
       operandStack2.remove(operandStack2.size()-1);
       int value1=Integer.parseInt(operandStack2.get(operandStack2.size()-1));
       operandStack2.remove(operandStack2.size()-1);
       
       String newValue;
       switch(op){
           case "+": newValue=""+(value1+value2); 
           case "-":newValue=""+(value1-value2);
           case "*":newValue=""+(value1*value2);
           case "/":newValue=""+(value1/value2);
           
           operandStack2.add(newValue);
       
       }

