/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1gui1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Chaos
 */
public class InfixEval1 {
    

 public static void pop(){
    
    }
    public static void push(){
    
    }
   
    
    private String userString= "(4+5)";
    
    //private String [] masterStack = new String[1];
    //private String [] operatorStack1 = new String[1];
    //private String [] operandStack2 = new String[1];
    

    public static void main (String[] args){
        InfixEval1 calculation=new InfixEval1();

    calculation.evaluate();
}
   public void evaluate(){
     ArrayList<String>operatorStack1=new ArrayList<>();
     ArrayList<String>operandStack2=new ArrayList<>();
     List<String> masterStack3 = new ArrayList<>(Arrays.asList(userString.split(",")));     
     //operatorStack1.add("(");
       userString=userString.replaceAll("\\s+","");//delete all spaces
       StringBuilder sb=new StringBuilder(userString);//create stringbuilder object
       

       //puts comma between all tokens
       for(int i=0;i<sb.length();i++){
       if(sb.charAt(i)=='/'||sb.charAt(i)=='*'||sb.charAt(i)=='+'||sb.charAt(i)=='-'||sb.charAt(i)==')'||sb.charAt(i)=='('){
    
       sb.insert(i, ',');
       sb.insert(i+2, ',');
       i++;
      }
       }
       
       //deletes extra commas
        for(int i=0;i<sb.length()-1;i++){
        if (sb.charAt(i)==','&&sb.charAt(i+1)==','){
        sb.deleteCharAt(i);
        i++;
        }
        }
       
       //deletes extra commas if they appear in the front or back of the string
       if (sb.charAt(0)==','){
       sb.deleteCharAt(0);
       }
       if (sb.charAt(sb.length()-1)==','){
       sb.deleteCharAt(sb.length()-1);
       }
       
       System.out.println(sb);
       userString=sb.toString();//gives userString the value of sb
       
       System.out.println(masterStack3);
       
       
       //masterStack=userString.split(",");//loads everything on to stacks
       //operatorStack1=new String[masterStack.length];
       //operandStack2=new String[masterStack.length];;
       

       
      // System.out.println("\n ELEMENT ZERO"+masterStack[0]);
       //System.out.println("\n FINAL ELEMENT"+masterStack[masterStack.length-1]);
       
       

       
//       System.out.println("operatorStack1:");
//       for (int i=operatorStack1.length-1;i>-1;i--){
//       System.out.println(operatorStack1[i]);
//       }
//       System.out.println("operandStack2:");
//       for (int i=operandStack2.length-1;i>-1;i--){
//       System.out.println(operandStack2[i]);
//       }
//       //return ""+operatorStack1+"\n"+operandStack2;
   }

   
}
