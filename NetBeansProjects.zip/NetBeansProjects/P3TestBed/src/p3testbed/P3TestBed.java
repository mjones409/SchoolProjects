/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p3testbed;

import java.util.Stack;

/**
 *
 * @author Chaos
 */
public class P3TestBed {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        TestTree tree1=new TestTree();
        
        tree1.insert(3);
        tree1.insert(2);
        tree1.insert(1);
        tree1.insert(5);
        tree1.insert(9);
        
        tree1.display(tree1.root);
         

    }
    
}
