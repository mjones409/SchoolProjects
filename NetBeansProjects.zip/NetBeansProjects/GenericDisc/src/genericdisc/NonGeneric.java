/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package genericdisc;

import java.util.ArrayList;
import java.util.List;
public class NonGeneric {
    public static void main(String[] args) {
        List sl= new ArrayList();
        sl.add("bob");
        sl.add("tim");
        sl.add(3);
        String list1=(String)sl.get(0);
        String list2=(String)sl.get(1);
        String list3=(String)sl.get(2);
        System.out.println(list1);
        System.out.println(list2);
        System.out.println(list3);
    }
}
