/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package genericdisc;

import java.util.ArrayList;
import java.util.List;
public class GenericDisc  {
    public static void main(String[] args) {
       // ArrayList<Integer> list = new ArrayList();
        List<String> sl= new ArrayList<>();
        List<String> s2 = new ArrayList<>(); 
         s2.add("b");
        s2.add("t");
        s2.add("t");
        sl.add("bob");
        sl.add("bob");
        sl.add("three");
        String list1=sl.get(0);
        String list2=sl.get(1);
        String list3=sl.get(2);
        ///System.out.println(list1);
        //System.out.println(list2);
        //System.out.println(list3);
         
        String list4=s2.get(0);
        String list5=s2.get(1);
        String list6=s2.get(2);
        sl.addAll(s2);
        String element = "bob";
for (int i = sl.size() - 1; i >= 0; i--)
   if (sl.get(i).equals(element))
       sl.remove(element);
        System.out.println(sl);
                System.out.println(s2);

        //System.out.println(list1);
        //System.out.println(list2);
        //System.out.println(list3);
        
         
    }
    public interface Tom<T,F> {
    
    }
}
