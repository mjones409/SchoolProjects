/*
File:Student.java
Author: Marcus Jones
Date: 10 March 2019
Purpose: Final Project
 */
package finalproject;

import java.util.ArrayList;


public class Student extends FinalProject{
    
static ArrayList sList=new ArrayList();//Array List holding student info (NOT student id)
private String studentName;
private String studentMajor;
private static double totalCredits;
private static double qp;//quality points
private static int u;//variable used to look at elements in the arraylist (see below)
private static double gpa;

        
    public Student(String nameVar, String majorVar){
      studentName=nameVar;
      studentMajor=majorVar;
      totalCredits=0;
      qp=0;
      gpa=0;
      if (sList.contains("Name: "+nameVar+"\nMajor: "+majorVar)){
          //do nothing if the student is already in the array list
      }
      else
      sList.add("Name: "+nameVar+"\nMajor: "+majorVar);
      sList.add(qp);
      sList.add(totalCredits);
      sList.add(gpa);


      
    }
    public static void courseCompleted(double c, double g){
        
        u=sList.indexOf(nameVar);
        Object list1=sList.get(u+1);
        String list2=list1.toString();
        totalCredits = Double.parseDouble(list2);
        
        list1=sList.get(u+2);
        list2=list1.toString();
        qp = Double.parseDouble(list2);
        
        sList.set(u+1,c+totalCredits );//setting total credits
        sList.set(u+2,qp+(g*c) );//setting quality points
        gpa=(qp+(g*c))/(c+totalCredits);//calculating gpa
        sList.set(u+3,gpa);//setting gpa
        
    }
    @Override
    public String toString(){
        u=sList.indexOf(nameVar);
        
        Object nameO=sList.get(u);
        String nameS=nameO.toString();
        
        Object gpaOb=sList.get(u+3);
        String gpaString=gpaOb.toString();
        if (gpaString.contentEquals("0.0")){//if they have no grades in, give them a 4.0
        gpaString="4.0";
        }
    return nameS+"\nGPA: "+gpaString;//return the name and major as well as gpa
    }
    
}

