/*
File:FinalProject.java
Author: Marcus Jones
Date: 10 March 2019
Purpose: Final Project
 */
package finalproject;

import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


public class FinalProject extends JFrame{
    //JLABELS
private static final JLabel IDLABEL = new JLabel("Id:    ");
private static final JLabel NAMELABEL = new JLabel("Name:  ");
private static final JLabel MAJORLABEL = new JLabel("Major: ");
private static final JLabel SELECTIONLABEL = new JLabel("Choose Selection:");
//JTEXTFIELDS
private static  JTextField id;//ID number
private static JTextField name;//student name
private static JTextField major;//student major
public static JFrame f = new JFrame("Project 4");
private static final String[] SELECTIONBOX = { "Insert", "Delete", "Find", "Update" };
private static final JComboBox SELECTION = new JComboBox(SELECTIONBOX);
private static final HashMap<Integer,String>MAP=new HashMap<>();//HASHMAP
private static final String[] GRADEBOX = { "A", "B", "C", "D","F" };
private static final String[] CREDITBOX = { "3", "6"};
private static final JComboBox GRADE = new JComboBox(GRADEBOX);
private static final JComboBox CREDIT = new JComboBox(CREDITBOX);
//MISC VARIABLES
static String nameVar;
static String majorVar;
static double gradeVar;
static double creditVar;
private static int tempId;
private static int a;
private static String tempNameMaj;


	 public static void main(String[] args) {
             //creating JFrame
    f.getContentPane().setLayout(new FlowLayout());
    f.setLocationRelativeTo(null);
     //creating buttons
JButton request=new JButton("                 Process Request                 ");     
//creating text field
    id = new JTextField("",15);
    name = new JTextField("",15);
    major = new JTextField("",15);
    //adding components
    f.add(IDLABEL);
    f.add(id); 
    f.add(NAMELABEL);
    f.add(name);    
    f.add(MAJORLABEL);
    f.add(major);    
    f.add(SELECTIONLABEL);
    f.add(SELECTION);
    f.add(request);   
    f.setSize(250,200);
    f.setVisible(true);
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
    //selection item listener
                SELECTION.addItemListener(new ItemListener() {
                @Override
		public void itemStateChanged(ItemEvent event) {
                    //INSERT
                    if(SELECTION.getSelectedIndex()==0){
                    id.setText("");
                    name.setText("");
                    major.setText("");
                    id.setEditable(true);
                    name.setEditable(true);
                    major.setEditable(true);
                                }
                    //NOT INSERT
                    if(SELECTION.getSelectedIndex()==1||SELECTION.getSelectedIndex()==2||SELECTION.getSelectedIndex()==3){
                    id.setText("");
                    name.setText("");
                    major.setText("");
                    id.setEditable(true);
                    name.setEditable(false);
                   major.setEditable(false);
                                }                           
			}          
	      });//end selection item listener  
                
                
                                     // request button action listener
                    request.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
                            
                            //INSERT selected
                            if (SELECTION.getSelectedIndex()==0){
                                try{
                            if (MAP.get(Integer.parseInt(id.getText()))==null){
                            nameVar=name.getText();
                            majorVar=major.getText();
                            
                            Student student1=new Student(nameVar,majorVar);
                            
                            MAP.put(Integer.parseInt(id.getText()),"Name: "+name.getText()+"\nMajor: "+major.getText());
                            JOptionPane.showMessageDialog(f,"SUCCESS!\nid: "+id.getText()+"\nName: "+name.getText()+"\nMajor: "+major.getText()+"\nHas Been Added.");
                            }
                            else{
                            JOptionPane.showMessageDialog(f,"ERROR!\nid: "+id.getText()+"\nHas Been Taken.");
                            }
                            }
                            catch(Exception e){
                            JOptionPane.showMessageDialog(f,
                            "Not a valid number.");                            }
			}//end insert          
                            
                            //DELETE selected
                            if (SELECTION.getSelectedIndex()==1){
                                try{
                           if (MAP.get(Integer.parseInt(id.getText()))!=null){
                            tempId=Integer.parseInt(id.getText());
                            tempNameMaj=MAP.get(tempId);
                            MAP.remove(Integer.parseInt(id.getText()));
                           
                            
                            a=Student.sList.indexOf(tempNameMaj);
                            Student.sList.remove(a);
                            Student.sList.remove(a);
                            Student.sList.remove(a);
                            Student.sList.remove(a);
                            
                            
                            JOptionPane.showMessageDialog(f,"SUCCESS!\nid: "+id.getText()+"\nHas Been Deleted.");
                            }
                            else{
                            JOptionPane.showMessageDialog(f,"ERROR!\nid: "+id.getText()+"\nDoes Not Exist.");
                            }
                            }
                            catch(Exception e){
                            JOptionPane.showMessageDialog(f,
                            "Not a valid number.");                            }
			}//end delete          
                            
                            //FIND selected
                            if (SELECTION.getSelectedIndex()==2){
                                try{
                            if (MAP.get(Integer.parseInt(id.getText()))!=null){
                            nameVar=MAP.get(Integer.parseInt(id.getText()));
                            Student student1=new Student(nameVar,majorVar);
                            JOptionPane.showMessageDialog(f,"SUCCESS!\nid: "+id.getText()+"\n"+student1.toString());
                            }
                            else{
                            JOptionPane.showMessageDialog(f,"ERROR!\nid: "+id.getText()+"\nDoes Not Exist.");
                            }
                            
                            }
                            catch(Exception e){
                            JOptionPane.showMessageDialog(f,
                            "Not a valid number.");                            }
			}//end find          
                            
                            //UPDATE selected
                            if (SELECTION.getSelectedIndex()==3){
                                try{
                            if (MAP.get(Integer.parseInt(id.getText()))!=null){
                            JOptionPane.showMessageDialog(f, GRADE,"Choose Grade:",1);
                            if(GRADE.getSelectedIndex()==0){gradeVar=4;}
                            if(GRADE.getSelectedIndex()==1){gradeVar=3;}
                            if(GRADE.getSelectedIndex()==2){gradeVar=2;}
                            if(GRADE.getSelectedIndex()==3){gradeVar=1;}
                            if(GRADE.getSelectedIndex()==4){gradeVar=0;}
                            JOptionPane.showMessageDialog(f, CREDIT,"Choose Credits:",1);
                            if(CREDIT.getSelectedIndex()==0){creditVar=3;}
                            if(CREDIT.getSelectedIndex()==1){creditVar=6;}
                            nameVar=MAP.get(Integer.parseInt(id.getText()));
                            Student.courseCompleted(creditVar,gradeVar);
                            JOptionPane.showMessageDialog(f,"SUCCESS!\nid: "+id.getText()+"\n"+MAP.get(Integer.parseInt(id.getText()))+"\nHas Been Updated.");

                            }
                            else{
                            JOptionPane.showMessageDialog(f,"ERROR!\nid: "+id.getText()+"\nDoes Not Exist.");
                            }
                            }
                            catch(Exception e){
                            JOptionPane.showMessageDialog(f,
                            "Not a valid number.");                            }
			}//end update          
}//end action listener         
	      });//end request button listener
		  }//end main
}//end class