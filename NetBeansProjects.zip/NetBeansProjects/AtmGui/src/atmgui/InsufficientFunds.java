/*
File:InsufficientFunds.java
Author: Marcus Jones
Date: 9 Feb 2019
Purpose: week 4 project
 */
package atmgui;
import javax.swing.*;


class InsufficientFunds extends Exception {
    
    InsufficientFunds(String exception2){
        
        JOptionPane.showMessageDialog(AtmGui.f,
                            "Insufficient funds. Not enough money in that account.");
        
    }
    
}
