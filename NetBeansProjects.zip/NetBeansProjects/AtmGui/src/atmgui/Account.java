/*
File:Account.java
Author: Marcus Jones
Date: 9 Feb 2019
Purpose: week 4 project
 */
package atmgui;
import javax.swing.*;
import java.text.DecimalFormat;


public class Account extends AtmGui{
private static DecimalFormat df = new DecimalFormat("#,###,##0.00");
private float checking;
private float savings;
private String placeholder;
private static int serviceChargeCounter=0;
private static float serviceCharge=0;

    //constructor for checking
   public Account(float checking){
    this.checking=checking;
    } 
   //constructor for savings
   public Account(float savings,String placeholder){
    this.savings=savings;
    this.placeholder=placeholder;
    } 

   //method for withdraw
   public static void doWithdraw(){
       if (serviceChargeCounter>=4){//changes service charge to $1.50 after 4 successful withdraws
       serviceCharge=1.50f;
       }
       
       //checking
       if (AtmGui.cs==1){
           try{
       if (AtmGui.dollarAmmount+serviceCharge<=checkingAccount.checking){
           checkingAccount.checking=checkingAccount.checking-AtmGui.dollarAmmount-serviceCharge;
           serviceChargeCounter++;
       JOptionPane.showMessageDialog(AtmGui.f,
                            "Success! \n You recieved $"+df.format(AtmGui.dollarAmmount)+" from checking.\n"
                                    + "Your new checking balance is $"+df.format(checkingAccount.checking)+"."
                                    +"\n Service charge: $"+df.format(serviceCharge));}
       else{throw new InsufficientFunds("");}
           }
           catch(InsufficientFunds exp){
           }
       }
       
       //savings
       if (AtmGui.cs==2){
           try{
       if (AtmGui.dollarAmmount+serviceCharge<=savingsAccount.savings){     
           savingsAccount.savings=savingsAccount.savings-AtmGui.dollarAmmount-serviceCharge;
           serviceChargeCounter++;
           JOptionPane.showMessageDialog(AtmGui.f,
                            "Success! \n You recieved $"+df.format(AtmGui.dollarAmmount)+" from savings.\n"
                                    + "Your new savings balance is $"+df.format(savingsAccount.savings)+"."
                                    +"\n Service charge: $"+df.format(serviceCharge));
       }
       else throw new InsufficientFunds("");
           }
           catch(InsufficientFunds exp){
           }       
       }
       
       }//end withdraw method
   
         //method for deposit
        public static void doDeposit(){
            //checking
            if (AtmGui.cs==1){
                checkingAccount.checking=checkingAccount.checking+AtmGui.dollarAmmount;
                JOptionPane.showMessageDialog(AtmGui.f,
                            "Success! \n You deposited $"+df.format(AtmGui.dollarAmmount)+" to checking.\n"
                                    + "Your new checking balance is $"+df.format(checkingAccount.checking)+".");
            }
            //savings
            if (AtmGui.cs==2){
                savingsAccount.savings=savingsAccount.savings+AtmGui.dollarAmmount;
                JOptionPane.showMessageDialog(AtmGui.f,
                            "Success! \n You deposited $"+df.format(AtmGui.dollarAmmount)+" to savings.\n"
                                    + "Your new savings balance is $"+df.format(savingsAccount.savings)+".");
            }
        }//end deposit method
        
        //transfer method
        public static void doTransfer(){
            
            //checking
            if (AtmGui.cs==1){
           try{
                if (AtmGui.dollarAmmount<=savingsAccount.savings){
                
                    savingsAccount.savings=savingsAccount.savings-AtmGui.dollarAmmount;
                    checkingAccount.checking=checkingAccount.checking+AtmGui.dollarAmmount;
                    JOptionPane.showMessageDialog(AtmGui.f,
                            "Success! \n You transferred $"+df.format(AtmGui.dollarAmmount)+" from savings to checking.\n"
                                    + "Your new savings balance is $"+df.format(savingsAccount.savings)+".\n"
                                    +"Your new checking balance is $"+df.format(checkingAccount.checking)+".");
                }
                else throw new InsufficientFunds("");
           }
           catch(InsufficientFunds exp){
           }       
            }
            
                //savings
                if (AtmGui.cs==2){
           try{
                    if (AtmGui.dollarAmmount<=checkingAccount.checking){
                    checkingAccount.checking=checkingAccount.checking-AtmGui.dollarAmmount;
                    savingsAccount.savings=savingsAccount.savings+AtmGui.dollarAmmount;
                    JOptionPane.showMessageDialog(AtmGui.f,
                            "Success! \n You transferred $"+df.format(AtmGui.dollarAmmount)+" from checking to savings.\n"
                                    + "Your new checking balance is $"+df.format(checkingAccount.checking)+".\n"
                                    +"Your new savings balance is $"+df.format(savingsAccount.savings)+".");
                }
                else throw new InsufficientFunds("");
           }
           catch(InsufficientFunds exp){
           }       
            }
        }//end transfer method
        
                //balance method
                public static void showBalance(){
                    
                //checking
                if (AtmGui.cs==1){
                JOptionPane.showMessageDialog(AtmGui.f,
                        "Your checking balance is $"+df.format(checkingAccount.checking)+".");
                }
                
                //savings
                if (AtmGui.cs==2){
                JOptionPane.showMessageDialog(AtmGui.f,
                        "Your savings balance is $"+df.format(savingsAccount.savings)+".");
                }
                }//end balance method
        
        }
   

