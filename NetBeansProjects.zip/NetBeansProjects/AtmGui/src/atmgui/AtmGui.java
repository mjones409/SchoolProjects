/*
File:AtmGui.java
Author: Marcus Jones
Date: 9 Feb 2019
Purpose: week 4 project
 */
package atmgui;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class AtmGui extends JFrame {
  private static JTextField inputBox;//input field
  public static float dollarAmmount;//user's input number
  private static String input;//user's input in string form
  public static int cs=1;//1 for checking, 2 for savings
  public static JFrame f = new JFrame("ATM Machine");
  //creating new objects with the ammount of money I want in each account to start with
  public static Account checkingAccount=new Account(1000f);
  public static Account savingsAccount=new Account(1000f,"");


	 public static void main(String[] args) {
                    //creating JFrame
		    f.getContentPane().setLayout(new FlowLayout());
		    //creating buttons
		    JButton withdraw=new JButton("     Withdraw     ");
                    JButton deposit=new JButton("     Deposit     ");
                    JButton transferTo=new JButton("     Transfer to     ");
                    JButton balance=new JButton("     Balance     ");
                    JRadioButton checkingRadio = new JRadioButton("Checking", true);
                    JRadioButton savingsRadio = new JRadioButton("Savings", false);
                    //creating text field
                    inputBox = new JTextField("",15);
                    //adding components
                    f.add(withdraw);
                    f.add(deposit);
                    f.add(transferTo);
                    f.add(balance);
                    f.add(checkingRadio);
                    f.add(savingsRadio);
                    f.getContentPane().add(inputBox);
                    //misc Jframe stuff
		    f.setSize(500,500);
		    f.setVisible(true);
                    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
                    
                    //checking radio button action listener
                    checkingRadio.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
                            savingsRadio.setSelected(false);
                            checkingRadio.setSelected(true);
                            cs=1;
			}          
	      });//end checking action listener
                    
                    //savings radio button action listener
                    savingsRadio.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
                            checkingRadio.setSelected(false);
                            savingsRadio.setSelected(true);
                            cs=2;
			}          
	      });//end savings action listener
                    
                    //withdraw button action listener
                    withdraw.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
                            try{
                            input=inputBox.getText();//sending the user's input to String input
                            dollarAmmount=Float.parseFloat(input);//sending String input to float dollarAmmount
                            if(dollarAmmount!=0 && dollarAmmount%20==0){
                            Account.doWithdraw();
                            }
                            else{
                            JOptionPane.showMessageDialog(f,
                            "Please withdraw in increments of $20");
                            }
                            }
                            catch(Exception e){
                            JOptionPane.showMessageDialog(f,
                            "Not a valid number.");                            }
			}          
	      });//end withdraw button listener
                    
                    //deposit button action listener
                    deposit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
                            try{
                            input=inputBox.getText();//sending the user's input to String input
                            dollarAmmount=Float.parseFloat(input);//sending String input to float dollarAmmount
                            Account.doDeposit();
                            }
                            catch(Exception e){JOptionPane.showMessageDialog(f,
                            "Not a valid number."); }
			}          
	      });//end deposit button listener
                    
                    //transferTo button action listener
                    transferTo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
                            try{
                            input=inputBox.getText();//sending the user's input to String input
                            dollarAmmount=Float.parseFloat(input);//sending String input to float dollarAmmount
                            Account.doTransfer();
                            }
                            catch(Exception e){JOptionPane.showMessageDialog(f,
                            "Not a valid number."); }
			}          
	      });//end transferTo button listener
                    
                    //balance button action listener
                    balance.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
                            Account.showBalance();
			}          
	      });//end balance button listener
                    
		  }

    }

