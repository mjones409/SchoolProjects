/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package incdec;

/**
 *
 * @author Chaos
 */
public class IncDec {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

int a=1;
int b=2;
int c;
int d;

c=++b;
++c;

d=a++;

System.out.println("c "+c +"\nb "+b);
System.out.println("d "+d +"\na "+a);
        }
    
}
