package cmsc451disc4;

import java.util.Arrays;

public class CMSC451Disc4 {

    public static void main(String[] args) {
        int[] denoms = new int[]{5, 10, 25, 50, 100};
        int change = 49;
        int[] storedAnswers = new int[change + 1];
        Arrays.fill(storedAnswers, change + 1);
        storedAnswers[0] = 0;
        for (int i = 1; i <= change; i++) {
            for (int j = 0; j < denoms.length; j++) {
                if (denoms[j] <= i) {
                    if (storedAnswers[i] > storedAnswers[i - denoms[j]] + 1) {
                        storedAnswers[i] = storedAnswers[i - denoms[j]] + 1;
                    }
                }
            }
        }
        if (storedAnswers[change] > change) {
            System.out.println("You Can Not Make Change");
        } else {
            System.out.println(storedAnswers[change]);
        }
    }
}
