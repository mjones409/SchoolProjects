/*
 * File:BinaryTree.java
 * Author: Marcus Jones
 * Date: 28 July 2019
 * Purpose: CMSC 350 Project 3
 */
package p3gui;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import javax.swing.JOptionPane;

public class BinaryTree<T extends Comparable<T>> {

    private TNode root;//root of tree
    private String[] tokenArray;
    private int[] intArray;
    private String output = "";
    private double[] fracArray;
    private Long dup;

// define class constructor(s)
    public String BinaryTree(String userInput, String adfi) throws P3GUI.MalformedFractionException {

        BinaryTree<Integer> bTree = new BinaryTree<>();
        BinaryTree<Double> fTree = new BinaryTree<>();

        switch (adfi) {
            //case 11 is ascending integers
            case "11":

                tokenArray = userInput.split(" ");//splits the user input and puts it into an array
                dup = Stream.of(tokenArray).distinct().count();//dup=the number of unique values in the array
                //checks if the number of unique elements is the same as the size of the array or not
                if (tokenArray.length != dup) {
                    JOptionPane.showMessageDialog(P3GUI.f, "You Have Duplicates");
                } else {
                    JOptionPane.showMessageDialog(P3GUI.f, "No Duplicates");
                }
                //converts the string array into an integer array
                intArray = new int[tokenArray.length];
                for (int i = 0; i < tokenArray.length; i++) {
                    intArray[i] = Integer.parseInt(tokenArray[i]);
                }
                //inserts  elements in to the tree
                bTree = insertInt(intArray.length, bTree);

                //creates arraylist of the elements and traverses the list
                List<Integer> inOrderList = new ArrayList<>();
                bTree.traverseInOrder(bTree.getRoot(), inOrderList);
                //String output is given the value of the list and formatted to get rid of all the unnecessary characters
                output = inOrderList.toString();
                output = output.replaceAll("\\[", "").replaceAll("\\]", "").replaceAll("[,]", "");
                // end of case 11

                break;

            case "12":

                //case 12 is ascending fractions
                /*creates a Frac instance and runs in with userInput as the 
                input gives fracArray the value of the output*/
                Frac frac1 = new Frac();
                fracArray = frac1.Frac(userInput);

                //inserts the fracArray into the tree
                fTree = insertFrac(fracArray.length, fTree);

                //creates arraylist of the elements and traverses the list
                List<Double> inOrderListF = new ArrayList<>();
                fTree.traverseInOrder(fTree.getRoot(), inOrderListF);
                for (int i = 0; i < inOrderListF.size(); i++) {
                    //output = the string format of the fractions by calling the toString method in Frac
                    output = output + frac1.toString(inOrderListF.get(i));
                }

                break;

            case "21":
                //case 21 is descending integers
                tokenArray = userInput.split(" ");//splits the user input and puts it into an array
                dup = Stream.of(tokenArray).distinct().count();//dup=the number of unique values in the array
                //checks if the number of unique elements is the same as the size of the array or not
                if (tokenArray.length != dup) {
                    JOptionPane.showMessageDialog(P3GUI.f, "You Have Duplicates");
                } else {
                    JOptionPane.showMessageDialog(P3GUI.f, "No Duplicates");
                }
                //converts the string array into an integer array

                intArray = new int[tokenArray.length];
                for (int i = 0; i < tokenArray.length; i++) {
                    intArray[i] = Integer.parseInt(tokenArray[i]);
                }
                //inserts  elements in to the tree
                bTree = insertInt(intArray.length, bTree);

                //creates arraylist of the elements and traverses the list
                List<Integer> reverseOrderList = new ArrayList<>();
                bTree.traverseReverseOrder(bTree.getRoot(), reverseOrderList);
                //String output is given the value of the list and formatted to get rid of all the unnecessary characters
                output = reverseOrderList.toString();
                output = output.replaceAll("\\[", "").replaceAll("\\]", "").replaceAll("[,]", "");

                //end of case 21
                break;

            case "22":

                //case 22 is descending fractions
                /*creates a Frac instance and runs in with userInput as the 
                input gives fracArray the value of the output*/
                Frac frac2 = new Frac();
                fracArray = frac2.Frac(userInput);

                //inserts the fracArray into the tree
                fTree = insertFrac(fracArray.length, fTree);

                //creates arraylist of the elements and traverses the list
                List<Double> reverseOrderListF = new ArrayList<>();
                fTree.traverseReverseOrder(fTree.getRoot(), reverseOrderListF);
                for (int i = 0; i < reverseOrderListF.size(); i++) {
                    //output = the string format of the fractions by calling the toString method in Frac
                    output = output + frac2.toString(reverseOrderListF.get(i));
                }

                break;

            default:

        }//end switch

        return output;//returns the output that was determined by a switch statement to P3GUI
    }

    public TNode getRoot() {
        return this.root;
    }

    //this method is called by the recursive insert method to add each object to the tree
    public void add(T data) {

        TNode<T> newNode = new TNode<T>(data);
        if (root == null) {
            root = newNode;
        } else {
            TNode<T> tempNode = root;
            TNode<T> prev = null;
            while (tempNode != null) {
                prev = tempNode;
                if (data.compareTo(tempNode.getData()) >= 0) {
                    tempNode = tempNode.getRight();
                } else {
                    tempNode = tempNode.getLeft();
                }
            }

            if (data.compareTo(prev.getData()) < 0) {

                prev.setLeft(newNode);
            } else {
                prev.setRight(newNode);

            }

        }
    }

    //for use traversing the tree in order
    public void traverseInOrder(TNode<T> root, List<T> storageList) {
        if (root != null) {
            traverseInOrder(root.getLeft(), storageList);
            storageList.add(root.getData());
            traverseInOrder(root.getRight(), storageList);
        }
    }

    //for use traversing the tree in reverse order
    public void traverseReverseOrder(TNode<T> root, List<T> storageList) {
        if (root != null) {
            traverseReverseOrder(root.getRight(), storageList);
            storageList.add(root.getData());
            traverseReverseOrder(root.getLeft(), storageList);
        }
    }

    //recursive insert method for integers
    private BinaryTree insertInt(int n, BinaryTree bt) {
        if (n == 0) {
            return bt;
        } else {
            bt.add(intArray[n - 1]);
            insertInt(n - 1, bt);
        }
        return bt;
    }

//recursive insert method for fractions
    private BinaryTree insertFrac(int n, BinaryTree bt) {
        if (n == 0) {
            return bt;
        } else {
            bt.add(fracArray[n - 1]);
            insertFrac(n - 1, bt);
        }
        return bt;
    }

}
