/*
 * File:TNode.java
 * Source:P3IndicationsFollowup
 * Date: 28 July 2019
 * Purpose: CMSC 350 Project 3
 */
package p3gui;

public class TNode<T extends Comparable<T>> {

    private T data;
    private TNode<T> left;
    private TNode<T> right;

    //setters and constructor
    public TNode(T data) {
        this.data = data;
    }

    public void setLeft(TNode<T> left) {
        this.left = left;
    }

    public void setRight(TNode<T> right) {
        this.right = right;
    }

    //getters
    public T getData() {
        return data;
    }

    public TNode<T> getLeft() {
        return left;
    }

    public TNode<T> getRight() {
        return right;
    }

}
