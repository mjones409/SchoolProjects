/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p3gui;



public class FractionC implements Comparable<FractionC>{
    private double input;
    
    public FractionC(String userInput){
        String [] tempArr=userInput.split("/");
        input=Double.parseDouble(tempArr[0])/Double.parseDouble(tempArr[1]);
        System.out.println(input);
    }

    @Override
    public int compareTo(FractionC o) {
       return Double.compare(this.input, o.input);
        }
        
        public String toString(int pLaCeHoLdEr){
        String s="";
    return s;
    }
    }

    
