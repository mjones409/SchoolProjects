/*
 * File:Frac.java
 * Author: Marcus Jones
 * Date: 28 July 2019
 * Purpose: CMSC 350 Project 3
 */
package p3gui;

import java.util.HashMap;
import java.util.stream.Stream;
import javax.swing.JOptionPane;
import p3gui.P3GUI.MalformedFractionException;

public class Frac implements Comparable<String> {

    private Long dup;//used to help determine if there are duplicate fractions

    //HASHMAP to associate the decimal and string forms of fractions
    private HashMap<Double, String> map = new HashMap<>();

    public double[] Frac(String input) throws MalformedFractionException {
        //splits the user input
        String[] fractionArray = input.split(" ");

        //dup equals the number of distinct elements in the array
        dup = Stream.of(fractionArray).distinct().count();
        //if dup=the length, we know there are no duplicates
        if (fractionArray.length != dup) {
            JOptionPane.showMessageDialog(P3GUI.f, "You Have Duplicates");
        } else {
            JOptionPane.showMessageDialog(P3GUI.f, "No Duplicates");
        }
        //array to store the decimal forms of the fractions
        double[] doubleArray = new double[fractionArray.length];

        /*mulitple things happen in this for loop. first a temporary 
        string array is created to store the numerator and denominator of the 
        current fraction and the fraction is split into the array*/
        for (int i = 0; i < fractionArray.length; i++) {
            String[] tempArr = fractionArray[i].split("/");
            //Second, a check is done to make sure there was exactly 1 numerator and 1 denominator
            if (tempArr.length != 2) {
                //otherwise,l throw an error
                throw new MalformedFractionException();
            }
            //third, the decimal form of the fraction is stored in doubleArray
            doubleArray[i] = Double.parseDouble(tempArr[0]) / Double.parseDouble(tempArr[1]);
            //Finally, the double and the string version of the fraction are placeed in the hashmap to be looked up later
            map.put(doubleArray[i], fractionArray[i]);
        }

        return doubleArray;

    }

    //toString takes the double form of the fraction and looks up the string version of it and returns that
    public String toString(double input) {
        String s = map.get(input) + " ";

        return s;
    }

    @Override
    public int compareTo(String f) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
