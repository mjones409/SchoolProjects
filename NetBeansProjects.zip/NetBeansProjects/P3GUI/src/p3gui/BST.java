/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p3gui;

import java.util.Arrays;
import java.util.Stack;

public class BST<T extends Comparable<T>> {
// define instance variables
private BSTnode root;

// define class constructor(s)
public String BST(String userInput,String adfi){ 
 
     /*tokenArray holds the user input in an array so that it 
     can be iterated through and put on the stack*/
        String[] tokenArray = userInput.split(" ");
        System.out.println(Arrays.toString(tokenArray));
        System.out.println(adfi);
        
        int [] intArray= new  int[tokenArray.length];
         for (int i=0;i<tokenArray.length;i++){
         intArray[i]=Integer.parseInt(tokenArray[i]);
         }
         System.out.println(Arrays.toString(intArray));
         
        BST<Integer> tree1=new BST<>();
        for (int i=0;i<intArray.length;i++){
        //for(int a=0; a<intArray.length ;a++){tree1.insertNode(a); System.out.println(a);}
        for (Integer n: intArray){ tree1.insertNode(n);
        //System.out.println(n);
        }
        }
        
    
return "";
}

// define the required methods
public void insertNode(T value) { 
// this method should invoke a recursive helper method
// insertNodeRecursive(value, root)    
if (root==null)
    root=new BSTnode(value);
    else
    insertNode(root,value);
        inorderTraversal(root);


}
    private void insertNode(BSTnode node, T value) {

        if(value.compareTo(node.value) < 0) {
            if(node.left == null)
                node.left = new BSTnode(value);
            else
                insertNode(node.left, value);
        }
        else {
            if(node.right == null)
                node.right = new BSTnode(value);
            else
                insertNode(node.right, value);
        }
    }
public String inorderTraversal(BSTnode answer) { 
    if (answer != null){
    inorderTraversal(answer.left);
    System.out.println(answer);
    inorderTraversal(answer.right);
    }
return ""+answer;
}

class BSTnode {
// instance variables
private T value;
private BSTnode left;
private BSTnode right;
// class constructor(s)
public BSTnode(T value){
    this.value=value;
    left=null;
    right=null;
}
// methods



}// end of class BSTnode



}// end of class BST
