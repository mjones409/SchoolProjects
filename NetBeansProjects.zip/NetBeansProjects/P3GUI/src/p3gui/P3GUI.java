/*
 * File:P3GUI.java
 * Author: Marcus Jones
 * Date: 28 July 2019
 * Purpose: CMSC 350 Project 3
 */
package p3gui;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class P3GUI extends JFrame {

    private static JTextField inputBox;//input field
    private static JTextField outputBox;//output 
    private static int ad = 1;//1 for ascending, 2 for descending
    private static int fi = 1;//1 for integer, 2 for fraction
    private static String adfi = "11";//tells the BST which sorting order and numeric type
    public static JFrame f = new JFrame("Binary Search Treee Sort");
    //JLABELS
    private static final JLabel INPUTLABEL = new JLabel("Original List:");
    private static final JLabel RESULTLABEL = new JLabel("Sorted List:");
    private static final JLabel SORTORDERLABEL = new JLabel("  Sort Order                                                               ");
    private static final JLabel NUMERICTYPELABEL = new JLabel("Numeric Type");

    public static void main(String[] args) {
        //creating JFrame
        f.getContentPane().setLayout(new FlowLayout());
        //creating buttons
        JButton performSort = new JButton("                                   Perform Sort                                   ");
        JRadioButton ascendingRadio = new JRadioButton("Ascending                                                 ", true);
        JRadioButton descendingRadio = new JRadioButton("Descending                                                ", false);
        JRadioButton integerRadio = new JRadioButton("Integer ", true);
        JRadioButton fractionRadio = new JRadioButton("Fraction", false);
        //creating text field
        inputBox = new JTextField("", 35);
        outputBox = new JTextField("", 35);
        //adding components
        f.add(INPUTLABEL);
        f.getContentPane().add(inputBox);
        f.add(RESULTLABEL);
        f.getContentPane().add(outputBox);
        f.add(performSort);
        f.add(SORTORDERLABEL);
        f.add(NUMERICTYPELABEL);
        f.add(ascendingRadio);
        f.add(integerRadio);
        f.add(descendingRadio);
        f.add(fractionRadio);
        outputBox.setEditable(false);
        //misc Jframe stuff
        f.setSize(400, 250);
        f.setVisible(true);
        f.setResizable(false);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Ascending radio button action listener
        ascendingRadio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                descendingRadio.setSelected(false);
                ascendingRadio.setSelected(true);
                ad = 1;
            }
        });//end ascending action listener

        //descending radio button action listener
        descendingRadio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                ascendingRadio.setSelected(false);
                descendingRadio.setSelected(true);
                ad = 2;
            }
        });//end descending action listener

        //integer radio button action listener
        integerRadio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                fractionRadio.setSelected(false);
                integerRadio.setSelected(true);
                fi = 1;
            }
        });//end integer action listener

        //fraction radio button action listener
        fractionRadio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                integerRadio.setSelected(false);
                fractionRadio.setSelected(true);
                fi = 2;
            }
        });//end fraction action listener

        //perform sort button action listener
        performSort.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                //if adfi ends with a 1 we know we are dealing with integers
                adfi = "" + ad + "" + fi;
                if (adfi.equals("11") || adfi.equals("21")) {
                    BinaryTree<Integer> aTree = new BinaryTree<>();

                    try {//number format exception
                        try {//malformed fraction exception

                            //output is displayed in outputBox
                            outputBox.setText("");

                            outputBox.setText(aTree.BinaryTree(inputBox.getText(), adfi));
                        } catch (MalformedFractionException mfe) {
                        }
                    } catch (NumberFormatException mfe) {
                        JOptionPane.showMessageDialog(P3GUI.f, "ERROR\nNon Numeric Input");
                        return;
                    }
                }
                //if adfi ends with 2 we know we are dealing with fractions
                if (adfi.equals("12") || adfi.equals("22")) {
                    BinaryTree<Double> dTree = new BinaryTree<>();
                    try {//number format exception
                        try {//malformed fraction exception

                            //output is displayed in outputBox
                            outputBox.setText("");

                            outputBox.setText(dTree.BinaryTree(inputBox.getText(), adfi));
                        } catch (MalformedFractionException mfe) {
                        }
                    } catch (NumberFormatException nfe) {
                        JOptionPane.showMessageDialog(P3GUI.f, "ERROR\nNon Numeric Input");
                    }
                }
            }

        });//end perform sort button listener

    }

    public static class MalformedFractionException extends Exception {

        MalformedFractionException() {
            //popup telling the user that their fracion was malformed
            JOptionPane.showMessageDialog(P3GUI.f, "ERROR\nMALFORMED FRACTION");

        }
    }
}
