/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amazonprep;

import java.util.Scanner;

public class AmazonPrep {
static Scanner myScanner=new Scanner(System.in);

    public static void main(String[] args) {
        int ron;
        int b;
        int i;
        ron=myScanner.nextInt();
       b=ron;
        while(ron!=b){
        
        }
        
        
        
    }
    
}
