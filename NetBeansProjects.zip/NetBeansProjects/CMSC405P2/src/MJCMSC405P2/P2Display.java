/* 
File: P2Display.java
Author: Marcus Jones
Date: 17 Nov 2019
Purpose: CMSC405 Project 2
 */
package MJCMSC405P2;

import com.jogamp.opengl.*;
import com.jogamp.opengl.util.gl2.GLUT;

class P2Display implements GLEventListener {

    //declare variables
    private final GLUT glut = new GLUT();
    private float mov1 = 0.0f;
    private float mov2 = -14.0f;
    private float mov3 = 0.0f;
    private float rot1 = 0.0f;
    private float rot2 = 0.0f;
    private float rot3 = 0.0f;
    private float rot4 = 0.0f;
    private float rot5 = 0.0f;

    @Override
    public void init(GLAutoDrawable glad) {
        GL2 gl = glad.getGL().getGL2();
        gl.glEnable(GL2.GL_DEPTH_TEST);
        gl.glLineWidth(2);
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_LIGHT0);
        gl.glEnable(GL2.GL_NORMALIZE);
        gl.glEnable(GL2.GL_COLOR_MATERIAL);

    }

    @Override
    public void display(GLAutoDrawable glad) {
        GL2 gl = glad.getGL().getGL2();
        gl.glClearColor(0f, 0f, 0f, 0);    // black background
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glLoadIdentity();
        gl.glOrtho(-15, 15, -10, 10, -30, 30);

        //call shape / transformation methods
        rhombicdodecahedron(gl);
        torus(gl);
        sphere(gl);
        teapot(gl);
        icosahedron(gl);
        cone(gl);

        //lighting
        float[] ambientLight = {1f, 0.6f, 0.6f, 0f};
        gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_AMBIENT, ambientLight, 0);
    }

    // RhombicDodecahedron shape and transform method
    private void rhombicdodecahedron(GL2 gl) {//method 1
        gl.glPushMatrix();
        gl.glColor3f(0.01f, 0.01f, 0.9f);
        gl.glTranslatef(mov2, 2.0f, -2.0f);
        mov2 += .005;
        glut.glutSolidRhombicDodecahedron();
        gl.glPopMatrix();
    }

    // torus shape and transform method
    private void torus(GL2 gl) {//method 2
        gl.glPushMatrix();
        gl.glColor3f(0.4f, 0.75f, 0.9f);
        gl.glTranslatef(-10f, mov3, -2.0f);
        rot1 -= 2f;
        mov3 -= .001f;
        gl.glRotatef(rot1, 1f, 2f, 1.5f);
        glut.glutSolidTorus(1, 2, 3, 4);
        gl.glPopMatrix();

    }

    // wire sphere shape and transform method
    private void sphere(GL2 gl) {//method 3
        gl.glPushMatrix();
        gl.glColor3f(1f, 0.15f, 0.4f);
        gl.glTranslatef(-3.5f, -6f, -2.0f);
        rot2 += 0.5f;
        gl.glRotatef(rot2, 3f, 1f, 5f);
        glut.glutWireSphere(0.5, 4, 5);
        gl.glPopMatrix();

    }

    //  teapot shape and transform method
    private void teapot(GL2 gl) {//method 4
        gl.glPushMatrix();
        gl.glColor3f(1f, 1f, 1f);
        gl.glTranslatef(1f, 0.75f, -2.0f);
        gl.glRotatef(rot3, 0f, 0f, 1f);
        gl.glTranslatef(0.0f, mov1, 0.0f);
        glut.glutSolidTeapot(1);
        rot3 += 1;
        mov1 += .005;
        gl.glPopMatrix();
    }

    //  Icosahedron shape and transform method
    private void icosahedron(GL2 gl) {//method 5
        gl.glPushMatrix();
        gl.glColor3f(1f, 0.02f, 0.1f);
        gl.glTranslatef(4.5f, -3f, 2.0f);
        rot4 += 0.2f;
        gl.glRotatef(rot4, 0.0f, 1.0f, 50f);
        glut.glutWireIcosahedron();
        gl.glPopMatrix();
    }

    // cone shape and transform method
    private void cone(GL2 gl) {// method 6
        gl.glPushMatrix();
        gl.glColor3f(0.01f, 0.5f, 0.09f);
        gl.glTranslatef(10f, 5f, -2.0f);
        rot5 += 0.2f;
        gl.glRotatef(rot5, 1.0f, 0.0f, 0.0f);
        glut.glutSolidCone(1, 1, 25, 1);
        gl.glPopMatrix();
    }

    //implemented methods//
    @Override
    public void dispose(GLAutoDrawable glad) {
    }

    @Override
    public void reshape(GLAutoDrawable glad, int i, int i1, int i2, int i3) {
    }

}
