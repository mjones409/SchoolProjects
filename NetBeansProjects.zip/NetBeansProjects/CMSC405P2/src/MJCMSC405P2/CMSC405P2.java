/* 
File: CMSC405P2.java
Author: Marcus Jones
Date: 17 Nov 2019
Purpose: CMSC405 Project 2
 */
package MJCMSC405P2;

import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.util.Animator;
import java.awt.*;
import javax.swing.*;

public class CMSC405P2 extends JFrame {

    public static Animator animator = null;

    public static void main(String[] args) {
        final CMSC405P2 app = new CMSC405P2();
        app.setVisible(true);
        animator.start();
    }

    public CMSC405P2() {
        super("Marcus Jones Project 2");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        P2Display display = new P2Display();

        // create GLCanvas
        GLCapabilities glcaps = new GLCapabilities(null);
        GLCanvas glcanvas = new GLCanvas(glcaps);
        glcanvas.addGLEventListener(display);

        // create Animator
        animator = new Animator(glcanvas);

        // add GLCanvas to JFrame
        getContentPane().add(glcanvas, BorderLayout.CENTER);
        setSize(1000, 500);

    }

}
