/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animals;

/**
 *
 * 
 */


//class
public class Animals {
    private String animalType;
    private String animalColor;
    //constructor
    public Animals(String animalColor, String animalType){
    this.animalType=animalType;
    this.animalColor=animalColor;
    }
    //get type
   public String getAnimalType(){
       return animalType;
   } 
   // set type
   public void setAnimalType(String animalType){
       this.animalType=animalType;
   }
   //get color
    public String getAnimalColor(){
       return animalColor;
   }
    //set color
   public void setAnimalColor(String animalColor){
       this.animalColor=animalColor;
   }
   // toString method
   @Override
   public String toString(){
   return "I have a "+ animalColor+ " " +animalType;
   }
    
    
    
    
}
