/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guitar;

/*File: TestGuitar.java
*Author: Marcus Jones
*Date: 5 October 2018
*Purpose: week 4 homework
*/

import java.awt.Color;

public class TestGuitar {
    //main method
    public static void main(String[] args) {
        //inputting first Guitar details
       Guitar firstGuitar = new Guitar(6,28.2,"Gibson",Color.RED); 
       //printing the above info
       System.out.println("First Guitar:\n\n"+firstGuitar+"\n\n");
       
        //inputting second Guitar details
       Guitar secondGuitar = new Guitar(7,30,"Fender",Color.BLACK); 
       //printing the above info
       System.out.println("Second Guitar:\n\n"+secondGuitar+"\n\n");
       
        //inputting third Guitar details
       Guitar thirdGuitar = new Guitar(5,25.8,"Epiphone",Color.BLUE); 
       //printing the above info
       System.out.println("Third Guitar:\n\n"+thirdGuitar+"\n\n");

    }//end method main
}//end class TestGuitar
