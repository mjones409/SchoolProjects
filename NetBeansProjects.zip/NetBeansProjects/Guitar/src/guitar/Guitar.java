/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guitar;


/*File: Guitar.java
*Author: Marcus Jones
*Date: 5 October 2018
*Purpose: week 4 homework
*/

import java.util.*;
import java.awt.Color;

public class Guitar {
    
private int numStrings=6;// number of strings on the guitar
private double guitarLength=28.2; // length of the guitar
private String guitarManufacturer="Gibson"; //guitar manufacturer
private Color guitarColor= Color.RED; //color of guitar


//no arg constructor
public Guitar(int numStrings, double guitarLength, 
        String guitarManufacturer, Color guitarColor){
    //specified number of strings, length, etc.
    this.numStrings=numStrings;
    this.guitarLength=guitarLength;
    this.guitarManufacturer=guitarManufacturer;
    this.guitarColor=guitarColor;
}
    //getters
   public int getnumStrings(){
       return numStrings;
   } 
   public double getguitarLength(){
       return guitarLength;
   }
   public String getguitarManufacturer(){
       return guitarManufacturer;
   }
   public Color getguitarColor(){
       return guitarColor;
   }
   
   // setters
   public void setnumStrings(int numStrings){
       this.numStrings=numStrings;
   }
   public void setguitarLength(double guitarLength){
       this.guitarLength=guitarLength;
   }
   public void setguitarManufacturer(String guitarManufacturer){
       this.guitarManufacturer=guitarManufacturer;
   }
   public void setguitarColor(Color guitarColor){
       this.guitarColor=guitarColor;
   }
    
   //playGuitar() method
   public String playGuitar(){
       StringBuilder sb=new StringBuilder();
       
        float duration;//durration of note
        char note='z';//note we want to play
        float noteNum;//variable to change a random # into float
        int x=0;//x is how many times we want to execute the loop
        //start while loop
        while (x<16){
     // create random object for duration and notes
      Random dur = new Random();
      Random no= new Random();

      // check next int value for Random dur and assign it to duration
      duration=dur.nextInt(5);
      // check next int value for Random no
      noteNum=no.nextInt(7);
      
      //change random numbers from into valid notes
      if (noteNum==0){note='A';}
      if (noteNum==1){note='B';}
      if (noteNum==2){note='C';}
      if (noteNum==3){note='D';}
      if (noteNum==4){note='E';}
      if (noteNum==5){note='F';}
      if (noteNum==6){note='G';}
      
      //change random numbers into valid durations
      if (duration==0){duration=0.25f;}
      if (duration==1){duration=0.5f;}
      if (duration==2){duration=1f;}
      if (duration==3){duration=2f;}
      if (duration==4){duration=4f;}
      
      //turn the entire loop into one big string
      sb.append("[").append(note).append("(").append(duration).append(")]  ");
      
      //add to x so the loop isn't infinite
      x++;
        }
        //returning my long string
        return sb.toString();
   }
   @Override
   //toString method
   public String toString(){
   return "toString():\nStrings="+numStrings+", Length="+guitarLength+
           ", Manufacturer="+guitarManufacturer+", Color="
           +guitarColor+"\n"
           +"\n"+"getnumStrings():"+numStrings+"\n"+"getguitarLength():"
           +guitarLength+"\n"+"getguitarManufacturer():"+guitarManufacturer+"\n"
           +"getguitarColor():"+guitarColor+"\n\n"
           +"playGuitar():"+"\n"+""+playGuitar();
   }
   
}
