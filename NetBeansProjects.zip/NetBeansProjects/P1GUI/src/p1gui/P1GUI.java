/*
File:P1GUI.java
Author: Marcus Jones
Date: 27 June 2019
Purpose: CMSC 350 Project 1
 */
package p1gui;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.PrintWriter;

public class P1GUI extends JFrame {

    public static JFrame f = new JFrame("Infix Expression Evaluator");
    static String userInput;
    static String resultsToTxt = "";
    //JLABELS
    private static final JLabel INPUTLABEL = new JLabel("Enter Infix Expression:");
    private static final JLabel RESULTLABEL = new JLabel("Result:");
//JTEXTFIELDS
    private static JTextField input;//what the user inputs
    private static JTextField result;//results of the calculation

    public static void main(String[] args) {
        //creating JFrame
        f.getContentPane().setLayout(new FlowLayout());
        f.setLocationRelativeTo(null);
        //creating buttons
        JButton evaluate = new JButton("                                           Evaluate                                           ");
//creating text field
        input = new JTextField("", 15);
        result = new JTextField("", 10);
        //adding components
        f.add(INPUTLABEL);
        f.add(input);
        f.add(evaluate);
        f.add(RESULTLABEL);
        f.add(result);
        result.setEditable(false);
        f.setSize(400, 150);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // request button listener
        evaluate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                userInput = input.getText();
                resultsToTxt = resultsToTxt + userInput + " = ";
                InfixEval calculation = new InfixEval();
                try {
                    String calcResult = calculation.calculate(userInput);
                    result.setText(calcResult);
                    resultsToTxt = resultsToTxt + calcResult + "\n";
                } catch (ArithmeticException DivideByZero) {
                    resultsToTxt = resultsToTxt + "ERROR: Can't Divide by Zero" + "\n";
                    JOptionPane.showMessageDialog(f, "ERROR: Can't Divide by Zero");
                } catch (Exception IllegalToken) {
                    resultsToTxt = resultsToTxt + "ERROR: Illegal Token" + "\n";
                    JOptionPane.showMessageDialog(f, "ERROR: Illegal Token");
                }

            }
        });
        //close window listener
        f.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                try (PrintWriter myPrintWriter = new PrintWriter("Results.txt")) {
                    myPrintWriter.print(resultsToTxt);
                    myPrintWriter.close();
                    System.out.println("\nResults.txt Created");
                } catch (Exception FileError) {
                    JOptionPane.showMessageDialog(f, "ERROR: FILE ERROR");
                };
            }
        });

    }

}
