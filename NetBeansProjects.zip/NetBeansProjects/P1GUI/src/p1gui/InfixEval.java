/*
File:InfixEval.java
Author: Marcus Jones
Date: 30 June 2019
Purpose: CMSC 350 Project 1
 */
package p1gui;

import java.util.ArrayList;
import java.util.Arrays;

public class InfixEval {

    static ArrayList<String> operatorStack1 = new ArrayList<>();
    static ArrayList<String> operandStack2 = new ArrayList<>();
    static ArrayList<String> masterStack3 = new ArrayList<>();

    public static void doMath() {
        String op = operatorStack1.get(operatorStack1.size() - 1);
        operatorStack1.remove(operatorStack1.size() - 1);
        int value2 = Integer.parseInt(operandStack2.get(operandStack2.size() - 1));
        operandStack2.remove(operandStack2.size() - 1);
        int value1 = Integer.parseInt(operandStack2.get(operandStack2.size() - 1));
        operandStack2.remove(operandStack2.size() - 1);

        String newValue;
        switch (op) {
            case "+":
                newValue = "" + (value1 + value2);
                break;
            case "-":
                newValue = "" + (value1 - value2);
                break;
            case "*":
                newValue = "" + (value1 * value2);
                break;
            case "/":
                try {
                    newValue = "" + (value1 / value2);
                } catch (ArithmeticException DivideByZero) {
                    throw DivideByZero;
                }
                break;
            default:
                newValue = "10000";

        }//end switch
        operandStack2.add(newValue);
    }

    public static String calculate(String userString) {
        masterStack3.clear();
        operandStack2.clear();
        operatorStack1.clear();

        //operatorStack1.add("(");
        userString = userString.replaceAll("\\s+", "");//delete all spaces
        StringBuilder sb = new StringBuilder(userString);//create stringbuilder object

        //puts comma between all tokens
        for (int i = 0; i < sb.length(); i++) {
            if (sb.charAt(i) == '/' || sb.charAt(i) == '*' || sb.charAt(i) == '+' || sb.charAt(i) == '-' || sb.charAt(i) == ')' || sb.charAt(i) == '(') {

                sb.insert(i, ',');
                sb.insert(i + 2, ',');
                i++;
            }
        }

        //deletes extra commas
        for (int i = 0; i < sb.length() - 1; i++) {
            if (sb.charAt(i) == ',' && sb.charAt(i + 1) == ',') {
                sb.deleteCharAt(i);
                i++;
            }
        }

        //deletes extra commas if they appear in the front or back of the string
        if (sb.charAt(0) == ',') {
            sb.deleteCharAt(0);
        }
        if (sb.charAt(sb.length() - 1) == ',') {
            sb.deleteCharAt(sb.length() - 1);
        }

        userString = sb.toString();//gives userString the same value as sb
        String[] tempArray = userString.split(",");
        masterStack3.addAll(Arrays.asList(tempArray));

        ///////////////////////////////END OF FORMATTING/////////////////////
        for (int i = 0; i < masterStack3.size(); i++) {//iterate through masterStack3

            try {//check if number
                int numOrNot = Integer.parseInt(masterStack3.get(i));
                operandStack2.add(masterStack3.get(i));

            } catch (NumberFormatException notAnumber) {

            }//end of catch

            //check if left parenthesis
            if (masterStack3.get(i).equals("(")) {
                operatorStack1.add(masterStack3.get(i));
            } //check if right parenthesis
            else if (masterStack3.get(i).equals(")")) {

                while (operatorStack1.get(operatorStack1.size() - 1).equals("(") == false) {
                    doMath();

                }//end while loop
                operatorStack1.remove(operatorStack1.size() - 1);
            }// end right parenthesis check
            //check if operator
            else if (masterStack3.get(i).equals("+") || masterStack3.get(i).equals("-")
                    || masterStack3.get(i).equals("*") || masterStack3.get(i).equals("/")) {
                //check for precedence
                int precedence;
                if (operatorStack1.isEmpty() == false && ((masterStack3.get(i).equals("*") || masterStack3.get(i).equals("/")) && (operatorStack1.get(operatorStack1.size() - 1).equals("+") || operatorStack1.get(operatorStack1.size() - 1).equals("-")))) {
                    precedence = 0;
                } else if (operatorStack1.isEmpty() == false && (operatorStack1.get(operatorStack1.size() - 1).equals("(") || operatorStack1.get(operatorStack1.size() - 1).equals(")"))) {
                    precedence = 0;
                } else {
                    precedence = 1;
                }
                while (operatorStack1.isEmpty() == false && precedence == 1) {

                    String op = operatorStack1.get(operatorStack1.size() - 1);
                    doMath();
                }
                operatorStack1.add(masterStack3.get(i));
            }//end check if operator
        }//end of masterStack3 iterations
        while (operatorStack1.isEmpty() == false) {
            try {
                doMath();
            } catch (Exception IllegalToken) {
                throw IllegalToken;
            }
        }
        return operandStack2.get(operandStack2.size() - 1);
    }
}
