/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz1;

/**
 *
 * @author Chaos
 */
public class RecTest {
       public static void main(String[] args){

                double[] iterativeArray=new double[11];
                for(int i=0;i<11;i++){
            iterativeArray [i]=i;
                            System.out.println(iterativeArray[i]);

            }
                                            System.out.println(iterativeArray[10]);

       }
}
