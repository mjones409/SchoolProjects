/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz1;

/**
 *
 * @author Chaos
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Quiz1pt4 extends JFrame
{
   private JButton okButton = new JButton("OK");

   public Quiz1pt4()
   {
       add(okButton);
       okButton.addActionListener(
               new ActionListener()
               {
                   @Override
                   public void actionPerformed(ActionEvent ae)
                   {
                       System.out.println("The OK button is clicked");
                   }
               });
   }
   public static void main(String[] args)
   {
       JFrame frame = new Quiz1pt4();
       frame.setSize(300, 300);
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.setVisible(true);
   }
}

