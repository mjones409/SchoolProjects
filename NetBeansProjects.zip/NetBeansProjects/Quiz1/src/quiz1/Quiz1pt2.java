/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz1;

/**
 *
 * @author Chaos
 */
public class Quiz1pt2 {
    
   public static void main(String[] args)
   {
       int i = 1;
       StringBuilder s = new StringBuilder("s");
       String t = "t";

       someMethod(i, s, t);
       System.out.print("i = " + i + ", ");
       System.out.print("s = " + s + ", "); 
       System.out.println("t = " + t);
   }

   private static void someMethod(int i, StringBuilder s, String t)
   {
       i++;        
       s.append("s");
       t += "t";
   }
}