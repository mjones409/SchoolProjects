/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz1;

import java.util.Scanner;

/**
 *
 * @author Chaos
 */
public class Quiz1 {
static Scanner myScanner=new Scanner(System.in);
  static int apple=0;

    public static void main(String[] args) {
         Count count = new Count();
       int times = 0;

       for (int i = 0; i < 2; i++)
           increment(count, times); 
       System.out.println("times = " + times + " count = " + count.times);
   }

   public static void increment(Count count, int times)
   {
       count.times++;
       times++;
   }
}

class Count
{
   int times;

   public Count()
   {
       times = 1;
   }
}
