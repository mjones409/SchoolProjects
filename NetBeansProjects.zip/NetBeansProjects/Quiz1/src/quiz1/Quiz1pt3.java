/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz1;

/**
 *
 * @author Chaos
 */
public class Quiz1pt3 {
     //private static???????
   private static int i = 0;

   public static void main(String[] args)
   {
       {
           int i = 3;
                  System.out.println("i is " + i);

       }
       System.out.println("i is " + i);
   }
}
