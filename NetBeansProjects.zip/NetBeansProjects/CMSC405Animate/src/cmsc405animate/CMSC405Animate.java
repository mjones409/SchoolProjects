/* 
File: CMSC405Animate.java
Author: Marcus Jones
Date: 01 Nov 2019
Purpose: CMSC405 HW1
 */
package cmsc405animate;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import javax.swing.*;

public class CMSC405Animate extends JPanel {

    // A counter that increases by one in each frame.
    private int frameNumber = 1;
    static int translateX = 0;
    static int translateY = 0;
    static double rotation = 3 * Math.PI / 2;
    static double scaleX = 1.0;
    static double scaleY = 1.0;
    ImageTemplate405 myImages = new ImageTemplate405();
    BufferedImage faceImage = myImages.getImage(ImageTemplate405.face);
    BufferedImage stripeImage = myImages.getImage(ImageTemplate405.stripes);
    BufferedImage starImage = myImages.getImage(ImageTemplate405.star);

    public static void main(String[] args) {
        JFrame window;
        window = new JFrame("P1 Animation");
        final CMSC405Animate panel = new CMSC405Animate();
        window.setContentPane(panel);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.pack();
        window.setResizable(false);
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(
                (screen.width - window.getWidth()) / 2,
                (screen.height - window.getHeight()) / 2);
        Timer animationTimer;
        animationTimer = new Timer(1600, new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                if (panel.frameNumber > 4) {
                    panel.frameNumber = 1;
                } else {
                    panel.frameNumber++;
                }
                panel.repaint();
            }
        });
        window.setVisible(true); // Open the window, making it visible on the screen.
        animationTimer.start();  // Start the animation running.
    }

    public CMSC405Animate() {
        // Size of Frame
        setPreferredSize(new Dimension(1000, 500));
    }

    protected void paintComponent(Graphics g) {

        Graphics2D g2 = (Graphics2D) g.create();

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setPaint(Color.BLACK);
        g2.fillRect(0, 0, getWidth(), getHeight()); // From the old graphics API!

        applyWindowToViewportTransformation(g2, -75, 75, -75, 75, true);

        AffineTransform savedTransform = g2.getTransform();
        System.out.println("Frame is " + frameNumber);
        switch (frameNumber) {
            case 1: // First frame is unmodified.
                translateX = 0;
                translateY = 0;
                scaleX = 1.0;
                scaleY = 1.0;
                rotation = Math.toRadians(90 - 180);
                break;
            case 2: // Second frame translates each image by (-5, 7).
                translateX = -5;
                translateY = 7;
                break;
            case 3: // Third frame rotates each image by 45 degrees Counter
                rotation = rotation + Math.toRadians(45);
                break;
            case 4: // fourth frame rotates each image by 90 degrees clockwise
                rotation = rotation + Math.toRadians(-90);
                break;
            case 5: // fifth frame Scales 3 times x, 0.5 times y 
                scaleX = 2;
                scaleY = 0.5;
                break;
            // Can add more cases as needed 
            default:
                break;
        } // End switch
        g2.translate(translateX, translateY); // Move image.
        // To offset translate again
        g2.translate(0, 10);
        g2.rotate(rotation); // Rotate image.
        g2.scale(scaleY, scaleX); // Scale image.
        g2.drawImage(faceImage, 0, 0, this); // Draw image.
        g2.setTransform(savedTransform);

        // Add another image
        g2.translate(translateX, translateY); // Move image.
        // To offset translate again
        // This allows you to place your images across your graphic
        g2.translate(50, 10);
        g2.rotate(rotation); // Rotate image.
        g2.scale(scaleY, scaleX); // Scale image.
        g2.drawImage(stripeImage, 0, 0, this); // Draw image.
        g2.setTransform(savedTransform);

        // Add another image
        g2.translate(translateX, translateY); // Move image.
        // To offset translate again
        // This allows you to place your images across your graphic
        g2.translate(-50, 10);
        g2.rotate(rotation); // Rotate image.
        g2.scale(scaleY, scaleX); // Scale image.
        g2.drawImage(starImage, 0, 0, this); // Draw image.
        g2.setTransform(savedTransform);

    }

    // Method taken directly from AnimationStarter.java Code
    private void applyWindowToViewportTransformation(Graphics2D g2,
            double left, double right, double bottom, double top,
            boolean preserveAspect) {
        int width = getWidth();   // The width of this drawing area, in pixels.
        int height = getHeight(); // The height of this drawing area, in pixels.
        if (preserveAspect) {
            // Adjust the limits to match the aspect ratio of the drawing area.
            double displayAspect = Math.abs((double) height / width);
            double requestedAspect = Math.abs((bottom - top) / (right - left));
            if (displayAspect > requestedAspect) {
                // Expand the viewport vertically.
                double excess = (bottom - top) * (displayAspect / requestedAspect - 1);
                bottom += excess / 2;
                top -= excess / 2;
            } else if (displayAspect < requestedAspect) {
                // Expand the viewport vertically.
                double excess = (right - left) * (requestedAspect / displayAspect - 1);
                right += excess / 2;
                left -= excess / 2;
            }
        }
        g2.scale(width / (right - left), height / (bottom - top));
        g2.translate(-left, -top);
    }

}
