/*
File:Executive.java
Author: Marcus Jones
Date: 27 jan 2019
Purpose: week 2 project
 */
package employee;

/**
 *
 * @author Chaos
 */
class Executive extends Employee{
    private double sPrice;//stock price

    public Executive(String name, double mSalary, double sPrice){
    super (name, mSalary);
    this.sPrice=sPrice;
    ///this.mSalary=mSalary;

}

@Override
public double annualSalary(){
    double bonus=0;
    if(sPrice>50){bonus=30000;
    }
        
        return super.annualSalary()+bonus;
}

@Override
public String toString(){
return super.toString()+" stock price:"+sPrice+".";
}

public void display(){
System.out.println(""+toString());
}
}
