/*
File:Test.java
Author: Marcus Jones
Date: 27 jan 2019
Purpose: week 2 project
 */
package employee;
import java.io.File; 
import java.util.Scanner; 
/**
 *
 * @author Chaos
 */
public class Test {
     public static void main(String[] args)throws Exception  {
         Employee [] employeeArray2014=new Employee[10];
         Employee [] employeeArray2015=new Employee[10];
         //ArrayList<Employee>employeeArrayList2014=new ArrayList<Employee>();
         //ArrayList<Employee>employeeArrayList2015=new ArrayList<Employee>();
       
         
         //variables to be used for the employee objects
        int year;
        String employeeType;
        String employeeName;
        double employeeMonthlySalary;
        double aSalesOrStockPrice=0;
        boolean loopRunning=true;
        int employeeNumber2014=0;
        int employeeNumber2015=0;
        
        //specifying file
        File file = new File("C:\\Users\\Chaos\\Documents\\SCHOOL\\Intermediate Programming\\Week2\\EmployeeData.txt"); 
        //initializing scanner
        Scanner myScanner = new Scanner(file); 
         
        while (loopRunning==true){
            
        //prevents exception by only reading while there is something to read
        if (myScanner.hasNext()) {
            
        //reading file
        year=myScanner.nextInt();
        employeeType=myScanner.next();
        employeeName=myScanner.next();
        employeeMonthlySalary=myScanner.nextDouble();
        
        
        //checking to see if the employee has aSalesOrStockPrice
       if(employeeType.contentEquals("Salesman")||employeeType.contentEquals("Executive")) {aSalesOrStockPrice=myScanner.nextDouble();
       }
       

       
        //creating 10 employee objects
        if (employeeType.contentEquals("Employee")){
        
        if (year==2015){employeeArray2015[0+employeeNumber2015]=new Employee(employeeName,employeeMonthlySalary);
        employeeArray2015[0+employeeNumber2015].display();
        employeeNumber2015++;
        }
        
        if (year==2014){employeeArray2014[0+employeeNumber2014]=new Employee(employeeName,employeeMonthlySalary);
        employeeArray2014[0+employeeNumber2014].display();
        employeeNumber2014++;
        }
        }
        
        
        //creating 10 Salesman objects
        if (employeeType.contentEquals("Salesman")){
            
        if (year==2015){employeeArray2015[0+employeeNumber2015]=new Salesman(employeeName,employeeMonthlySalary,aSalesOrStockPrice);
        employeeArray2015[0+employeeNumber2015].display();
        employeeNumber2015++;
        }
        
        if (year==2014){employeeArray2014[0+employeeNumber2014]=new Salesman(employeeName,employeeMonthlySalary,aSalesOrStockPrice);
        employeeArray2014[0+employeeNumber2014].display();
        employeeNumber2014++;
        }
        }
        
        
        //creating 10 Executive objects
        if (employeeType.contentEquals("Executive")){
            
        if (year==2015){employeeArray2015[0+employeeNumber2015]=new Executive(employeeName,employeeMonthlySalary,aSalesOrStockPrice);
        employeeArray2015[0+employeeNumber2015].display();
        employeeNumber2015++;
        }
        
        if (year==2014){employeeArray2014[0+employeeNumber2014]=new Executive(employeeName,employeeMonthlySalary,aSalesOrStockPrice);
        employeeArray2014[0+employeeNumber2014].display();
        employeeNumber2014++;
        
        }
        
        }
        
        
        
        }
        //ends loop if there is nothing to read
        if (myScanner.hasNext()==false) {loopRunning=false;}



         }
        
                
               //PRINT 2014 ARRAY
                System.out.println("\n2014 ARRAY:");
                for (int i=0;i<3;i++){
                System.out.print((employeeArray2014)[0+i]+", annual salary:"+(employeeArray2014)[0+i].annualSalary()+".*** ");
                }
                System.out.println();
                for (int i=3;i<6;i++){
                System.out.print((employeeArray2014)[0+i]+", annual salary:"+(employeeArray2014)[0+i].annualSalary()+".*** ");
                }
                System.out.println();
                for (int i=6;i<9;i++){
                System.out.print((employeeArray2014)[0+i]+", annual salary:"+(employeeArray2014)[0+i].annualSalary()+".*** ");
                }
                System.out.println("\n"+(employeeArray2014)[9]+", annual salary:"+(employeeArray2014)[9].annualSalary()+".\n");
                
                
                //PRINT ANNUAL SALARY FOR 2014
                double average2014=0;
                for (int i=0;i<(employeeArray2014).length;i++){
                average2014=(employeeArray2014)[0+i].annualSalary()+average2014;
                }
                average2014=average2014/(employeeArray2014).length;
                System.out.println("average salary of 2014: "+average2014);
                
                
               //PRINT 2015 ARRAY
                System.out.println("2015 ARRAY:");
                for (int i=0;i<3;i++){
                System.out.print((employeeArray2015)[0+i]+", annual salary:"+(employeeArray2015)[0+i].annualSalary()+".*** ");
                }
                System.out.println();
                for (int i=3;i<6;i++){
                System.out.print((employeeArray2015)[0+i]+", annual salary:"+(employeeArray2015)[0+i].annualSalary()+".*** ");
                }
                System.out.println();
                for (int i=6;i<9;i++){
                System.out.print((employeeArray2015)[0+i]+", annual salary:"+(employeeArray2015)[0+i].annualSalary()+".*** ");
                }
                System.out.println("\n"+(employeeArray2015)[9]+", annual salary:"+(employeeArray2015)[9].annualSalary()+".\n");
                
                
                
                //PRINT ANNUAL SALARY FOR 2015
                double average2015=0;
                for (int i=0;i<(employeeArray2015).length;i++){
                average2015=(employeeArray2015)[0+i].annualSalary()+average2015;
                }
                average2015=average2015/(employeeArray2015).length;
                System.out.println("average salary of 2015: "+average2015);
        
                
                

    }
}
