/*
File:Salesman.java
Author: Marcus Jones
Date: 27 jan 2019
Purpose: week 2 project
 */
package employee;

/**
 *
 * @author Chaos
 */
class Salesman extends Employee{
    
    private double aSales;//anual sales
    private double commission;//how much the salesman gets in commission

public Salesman(String name, double mSalary, double aSales){
super (name, mSalary);
this.aSales=aSales;


}

@Override
public double annualSalary(){
        //double aSalary;
        //aSalary=mSalary*12;
        
        
       // if (aSales > 20000){
        //aSales=20000;
        //}
        commission=aSales*0.02;
        if (commission>20000){commission=20000;}
        return super.annualSalary()+commission;
}

@Override
public String toString(){
return super.toString()+" annual sales: "+aSales+".";
}

public void display(){
System.out.println(""+toString());
}
    
}
