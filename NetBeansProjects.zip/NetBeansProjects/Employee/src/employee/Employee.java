/*
File:Employee.java
Author: Marcus Jones
Date: 27 jan 2019
Purpose: week 2 project
 */
package employee;

    

class Employee {
    private String name;
    private double mSalary;//monthly salary
    
    //constructor
    public Employee(String name, double mSalary){
    this.name=name;
    this.mSalary=mSalary;

    }
    
  public double annualSalary()
    {
        double aSalary;
        aSalary=mSalary*12;
        
        return aSalary;
    }
    
    public String toString(){
    return name+" monthly salary: "+mSalary;
    }
    public void display(){
System.out.println(""+toString());
}
    
}
