/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cmsc451hw2;

public class CMSC451hw2 {
private static int count=0;

  static int sum(int[] array, int first, int last) {
if (first == last){
        //  System.out.println("F "+first+" L "+last);
count++;
return array[first];
}
int mid = (first + last) / 2;
      //System.out.println("F "+first+" M "+mid+" L "+last);
count++;
return sum(array, first, mid) + sum(array, mid + 1, last);
}
    public static void main(String[] args) {
       int [] array={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30};
        System.out.println(sum(array,0,array.length-1));
        System.out.println(count);
        count=0;
        System.out.println(it(array,0,array.length-1));
        System.out.println(count);

    }
    public static int it(int[] array, int first, int last) {
        int answer = 0;
        for (int i = 0; i < array.length; i++) {
            answer = answer + array[i];
            count++;
        }
        return answer;
    }
}
