/*
 * File:AddOperator.java
 * Author: UMUC Content
 * Date: Retrieved 13 July 2019
 * Purpose: CMSC 350 Project 2
 */
package p2gui;

class AddOperator extends Operator {
    public double evaluate(double d1, double d2) {
        return d1 + d2;
    }
    
    public String toString() {
        return "+";
    }
}
