/*
 * File:P2GUI.java
 * Author: Marcus Jones
 * Date: 14 July 2019
 * Purpose: CMSC 350 Project 2
 */
package p2gui;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.PrintWriter;

//class that controls all the GUI and contains main method
public class P2GUI extends JFrame {
    //creates Jframe

    public static JFrame f = new JFrame("Three Address Generator");
//results that will be written to a .txt file
    private static String resultsToTxt = "";
    //JLABELS
    private static final JLabel INPUTLABEL = new JLabel("Enter Postfix Expression:");
    private static final JLabel RESULTLABEL = new JLabel("Infix Expression:");
//JTEXTFIELDS
    private static JTextField input;//what the user inputs
    private static JTextField result;//results of the calculation
    //program starts here

    public static void main(String[] args) {
        //creating JFrame
        f.getContentPane().setLayout(new FlowLayout());
        f.setLocationRelativeTo(null);
        //creating buttons
        JButton constructTree = new JButton("                                           Construct Tree                                           ");
//creating text field
        input = new JTextField("", 30);
        result = new JTextField("", 30);
        //adding components
        f.add(INPUTLABEL);
        f.add(input);
        f.add(constructTree);
        f.add(RESULTLABEL);
        f.add(result);
        result.setEditable(false);
        f.setSize(400, 200);
        f.setResizable(false);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // constructTree button listener
        constructTree.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                //creates an instance of the ExpressionTree class named tree1
                ExpressionTree tree1 = new ExpressionTree();

                //test for illegal token
                String inputTest = input.getText();//recieves the input
                //deletes all valid tokens
                inputTest = inputTest.replaceAll("[0-9,[-],[+],[*],[/],[.][ ]]", "");
                try {
                    //string should be empty because all valid tokens were deleted
                    if (inputTest.length() != 0) {
                        /* if string wasn't empty, ther must have been an invalid 
                              token so we throw the custom InvalidTokenException*/
                        throw new InvalidTokenException(inputTest);
                    }
                } catch (InvalidTokenException ite) {
                }

                /*try is to check for any other other errors in the 
                input like not adding spaces or adding too many.
                The assignment said we could assume the input was formatted correctly,
                however, I prefer to have something just in case*/
                try {
                    //currentAnswer is created and holds the user input
                    String currentAnswer = tree1.ExpressionTree(input.getText());
                    //gets int sp becomes the index of sp so that we can split the string
                    int sp = currentAnswer.indexOf("sp");
                    //the infix expression is everything before sp 
                    result.setText(currentAnswer.substring(0, sp));
                    //the currentAnswer becomes everything after sp
                    currentAnswer = currentAnswer.substring(sp + 2);

                    /*resultsToTxt continually adds currentAnswer 
                   on to it to make up the .txt file in the end*/
                    resultsToTxt = resultsToTxt + "\n" + currentAnswer + "\n";

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(f, "ERROR: \nSomething Went Wrong :( \nTry Again");
                }
            }
        });
        //close window listener
        f.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                try (PrintWriter myPrintWriter = new PrintWriter("Results.txt")) {
                    myPrintWriter.print(resultsToTxt);
                    myPrintWriter.close();
                    System.out.println("\nResults.txt Created");
                } catch (Exception FileError) {
                    JOptionPane.showMessageDialog(f, "ERROR: FILE ERROR");
                }
            }
        });

    }

}
