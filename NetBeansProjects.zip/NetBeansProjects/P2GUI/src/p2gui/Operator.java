/*
 * File:Operator.java
 * Author: UMUC Content
 * Date: Retrieved 13 July 2019
 * Purpose: CMSC 350 Project 2
 */
package p2gui;


public abstract class Operator {
   abstract public double evaluate(double x, double y);
}
