/*
 * File:ExpressionTree.java
 * Author: Marcus Jones
 * Date: 14 July 2019
 * Purpose: CMSC 350 Project 2
 */
package p2gui;

import java.util.*;
//this class handles all the program's logic

public class ExpressionTree {

//constructor that takes a string(input from user) and returns a string(program output)
    public String ExpressionTree(String userInput) {

        /*n counts the number of nodes in the tree 
by counting up each time a new node is added to nodeStack*/
        int n = 0;

        //nodeStack holds the tree nodes in a stack
        Stack<Node> nodeStack = new Stack<>();

        /*tokenArray holds the user input in an array so that it 
     can be iterated through and put on the stack*/
        String[] tokenArray = userInput.split(" ");

        //contains the 3-address instructions
        String address = "";

        //keeps the count of registers
        int rCount = 0;

        //for loop iterates over the array of tokens
        for (int i = 0; i < tokenArray.length; i++) {
            /*temporary nodes used because division 
            and subtraction are not commutative*/
            Node num2;
            Node num1;
            /*switch that checks whether the token is a number
                or an operator and applies the appropriate logic*/
            switch (tokenArray[i]) {
                case "+":
                    //pops the top two numbers
                    num2 = nodeStack.pop();
                    num1 = nodeStack.pop();
                    //adds the popped numbers
                    address = address + "Add " + "R" + rCount + " " + num1.evaluate() + " " + num2.evaluate() + "\n";
                    rCount++;//adds one to register count
                    //pushes the new value on to the stack
                    nodeStack.push(new OperatorNode(new AddOperator(), num1, num2));
                    n++;//since a value was pushed, we know a node was added to the tree
                    break;
                case "-":
                    //pops the top two numbers
                    num2 = nodeStack.pop();
                    num1 = nodeStack.pop();
                    //adds the popped numbers
                    address = address + "Sub " + "R" + rCount + " " + num1.evaluate() + " " + num2.evaluate() + "\n";
                    rCount++;//adds one to register count
                    //pushes the new value on to the stack
                    nodeStack.push(new OperatorNode(new SubOperator(), num1, num2));
                    n++;//since a value was pushed, we know a node was added to the tree
                    break;
                case "*":
                    //pops the top two numbers
                    num2 = nodeStack.pop();
                    num1 = nodeStack.pop();
                    //adds the popped numbers
                    address = address + "Mul " + "R" + rCount + " " + num1.evaluate() + " " + num2.evaluate() + "\n";
                    rCount++;//adds one to register count
                    //pushes the new value on to the stack
                    nodeStack.push(new OperatorNode(new MulOperator(), num1, num2));
                    n++;//since a value was pushed, we know a node was added to the tree
                    break;
                case "/":
                    //pops the top two numbers
                    num2 = nodeStack.pop();
                    num1 = nodeStack.pop();
                    //adds the popped numbers
                    address = address + "Div " + "R" + rCount + " " + num1.evaluate() + " " + num2.evaluate() + "\n";
                    rCount++;//adds one to register count
                    //pushes the new value on to the stack
                    nodeStack.push(new OperatorNode(new DivOperator(), num1, num2));
                    n++;//since a value was pushed, we know a node was added to the tree
                    break;
                default: //default must be a number since we already went through all the operators
                    //pushes the number on to the stack
                    nodeStack.push(new OperandNode(Double.parseDouble(tokenArray[i])));
                    n++;//since a value was pushed, we know a node was added to the tree

            }//end switch

        }//end for loop

        /*returns the top of the stack in infix form as a string
            + a split point so that we know where to split the string in P2GUI
            + the 3 address instructions
            + "Total nodes in the tree: "
            + the total number of nodes in the tree which equals n*/

        return nodeStack.peek().inOrderWalk() + "sp" + address + "Total nodes in the tree: " + n;
    }//end constructor
}//end class
