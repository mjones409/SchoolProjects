/*
 * File:OperatorNode.java
 * Author: UMUC Content
 * Date: Retrieved 13 July 2019
 * Purpose: CMSC 350 Project 2
 */
package p2gui;

/**
 *  This is the OperatorNode class. It evaluates the node
 *  to calculate its value, and it prints the tree
 *  in preorder, inorder, and postorder formats.
 */
public class OperatorNode implements Node {

    Node left, right;
    Operator operator;
   
    public OperatorNode(Operator operator, Node left,
                        Node right){
        this.operator = operator;
        this.left = left;
        this.right = right;
    }

    public double evaluate() {
        double leftValue = left.evaluate();
        double rightValue = right.evaluate();
        return operator.evaluate(leftValue, rightValue);
    } 
    
    public String preOrderWalk() {
        String leftValue = left.preOrderWalk();
        String rightValue = right.preOrderWalk();
        return "" + operator + " " + leftValue + " "
                  + rightValue;
    }

    public String inOrderWalk() {
        String leftValue = left.inOrderWalk();
        String rightValue = right.inOrderWalk();
        return "(" + leftValue + " " + operator + " "
                   + rightValue + ")";
    }

    public String postOrderWalk() {
        String leftValue = left.postOrderWalk();
        String rightValue = right.postOrderWalk();
        return leftValue + " " + rightValue + " " + operator;
    }
}

   
