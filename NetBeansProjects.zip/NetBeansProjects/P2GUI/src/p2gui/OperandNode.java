/*
 * File:OperandNode.java
 * Author: UMUC Content
 * Date: Retrieved 13 July 2019
 * Purpose: CMSC 350 Project 2
 */
package p2gui;

public class OperandNode implements Node {
    private double value;
    
    public OperandNode(double value) {
        this.value = value;
    }
    
    public double evaluate() {
        return value;
    }
    
    public String preOrderWalk() {
        return String.valueOf(value);
    }

    public String inOrderWalk() {
        return String.valueOf(value);
    }

    public String postOrderWalk() {
        return String.valueOf(value);
    }
}