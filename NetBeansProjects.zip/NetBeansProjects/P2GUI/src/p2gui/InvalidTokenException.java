/*
 * File:InvalidTokenException.java
 * Author: Marcus Jones
 * Date: 14 July 2019
 * Purpose: CMSC 350 Project 2
 */
package p2gui;

import javax.swing.JOptionPane;
//custom exception as required by the project guidelines
public class InvalidTokenException extends Exception {
    InvalidTokenException(String t){
        //popup telling the user the invalid tokens they entered
    JOptionPane.showMessageDialog(P2GUI.f, "ERROR\nInvalid Token(s): "+t);
}}
