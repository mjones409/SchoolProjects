/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coffeemaker;
/*
* File: CoffeeMaker.java
* Author: Dale J. Zimmerman
* Date: October 19, 2018
* Purpose: This program constructs instances
* of a CoffeeMaker class and uses
* its methods
*/

public class CoffeeMaker {    
    private String make;
    private String model;
    private boolean statusOn;
   
    // Constructor
    public CoffeeMaker (String make1, String model1, boolean statusOn1) { 
	make = make1;
	model = model1;
        statusOn = statusOn1;      
    }
  
    // Default constructor
    public CoffeeMaker () {		
	make = "Black&Decker";
	model = "G300";
        statusOn = false; 
    }
    
    // Setter methods
    // setMake()
    public void setMake(String make1) {
	make = make1;
    }
    // setModel()
    public void setModel(String model1) {	
	model = model1;
    }
    // setStatusOn()
    public void setStatusOn(boolean statusOn1) {	
	statusOn = statusOn1;
    }	

    // Getter methods
    // getMake()
    public String getMake() {
	return make;
    }    
    // getModel()
    public String getModel() {
	return model;
    }
    // getStatus()
    public boolean getStatusOn() {
	return statusOn;
    }

    // Convert status to String
    public String powerStatus() {
        if (statusOn==false)
        return "Power is OFF";
        
        else
        return "ON";
        }

    public static void main(String[] args)  { 

	// Construct a CoffeePot made by Apple
        CoffeeMaker smartCoffeeMaker = new CoffeeMaker("Apple", "Overpriced", true);   
        
	// Construct a default CoffeePot
	CoffeeMaker budgetCoffeeMaker = new CoffeeMaker();
        
        //constructor for my custom coffee maker
        CoffeeMaker myCoffeeMaker=new CoffeeMaker("Kureg","blue",false);
        
         // Print results for smartCoffeeMaker
	System.out.println("The new Budget Coffee maker by " + budgetCoffeeMaker.getMake() + 
                            " came in the " + budgetCoffeeMaker.getModel() +
                              " model and is On/Off: " + budgetCoffeeMaker.powerStatus());

	// Print results for smartCoffeeMaker
	System.out.println("The new Smart Coffee maker by " + smartCoffeeMaker.getMake() + 
                            " came in the " + smartCoffeeMaker.getModel() +
                              " model and is On/Off: " + smartCoffeeMaker.powerStatus());
        
        // Print results for smartCoffeeMaker
	System.out.println("My Coffee maker by " + myCoffeeMaker.getMake() + 
                            " came in the " + myCoffeeMaker.getModel() +
                              " model and is On/Off: " + myCoffeeMaker.powerStatus());
       

    }
}