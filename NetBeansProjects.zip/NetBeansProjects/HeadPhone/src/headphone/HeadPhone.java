package headphone;
/*File: HeadPhone.java
*Author: Marcus Jones
*Date: 20 October 2018
*Purpose: week 6 homework
*/
import java.awt.Color;
public class HeadPhone {

    private static final int LOW=1;
    private static final int MEDIUM=2;
    private static final int HIGH=3;
    private int volume=MEDIUM;
    private boolean pluggedIn=false;
    private String manufacturer="SkullCandy";
    private Color headPhoneColor= Color.RED;
    private String headPhoneModel="Standard Model";
    
    //changeVolume method
   public int changeVolume(int value){
      this.volume=value;
   return value;
   }
    
    //no arg constructor
public HeadPhone(int volume, boolean pluggedIn, String manufacturer, 
        Color headPhoneColor, String headPhoneModel){
    
    this.volume=volume;
    this.pluggedIn=pluggedIn;
    this.manufacturer=manufacturer;
    this.headPhoneColor=headPhoneColor;
    this.headPhoneModel=headPhoneModel;
}
    //getters
   public int getvolume(){
       return volume;
   } 
   public boolean getpluggedIn(){
       return pluggedIn;
   }
   public String getmanufacturer(){
       return manufacturer;
   }
   public Color getheadPhoneColor(){
       return headPhoneColor;
   }
    public String getheadPhoneModel(){
       return headPhoneModel;
   }
   
   // setters
   public void setvolume(int volume){
       this.volume=volume;
   }
   public void setpluggedIn(boolean pluggedIn){
       this.pluggedIn=pluggedIn;
   }
   public void setmanufacturer(String manufacturer){
       this.manufacturer=manufacturer;
   }
   public void setguitarColor(Color headPhoneColor){
       this.headPhoneColor=headPhoneColor;
   }
   public void setheadPhoneModel(String headPhoneModel){
       this.headPhoneModel=headPhoneModel;
   }
   
   //default constructor
   public HeadPhone () {		
    volume=MEDIUM;
    pluggedIn=false;
    manufacturer="SkullCandy";
    headPhoneColor= Color.RED;
    headPhoneModel="Standard Model";
    }
   
   
    
   
   //toString method
   @Override
   public String toString(){
   return " volume: "+volume+"\n plugged in: "+pluggedIn+"\n manufacturer: "
           +manufacturer+"\n head phone color: "+headPhoneColor+"\n model: "+headPhoneModel+"\n";
   }
   
   
   
    
    
}
