package headphone;

/*File: TestHeadPhone.java
*Author: Marcus Jones
*Date: 20 October 2018
*Purpose: week 6 homework
*/
import java.awt.Color;
//TestHeadPhone Class
public class TestHeadPhone {
    public static void main(String[] args) {
        // Construct a default HeadPhone
	HeadPhone defaultHeadPhone = new HeadPhone();
        System.out.println("defaultHeadPhone:\n"+defaultHeadPhone);

        //Construct second HeadPhone
        HeadPhone secondHeadPhone = new HeadPhone(3,false,"Beats",Color.ORANGE,"DELUX");
        //pass value into changeVolume method
        secondHeadPhone.changeVolume(1);
        System.out.println("secondHeadPhone:\n"+secondHeadPhone);
        
        //Construct third HeadPhone
        HeadPhone thirdHeadPhone = new HeadPhone(2,true,"Logitech",Color.YELLOW,"Premium");
        //pass value into changeVolume method
        thirdHeadPhone.changeVolume(3);
        System.out.println("thirdHeadPhone:\n"+thirdHeadPhone);
        
        
        
    }
}
