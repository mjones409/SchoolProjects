package cmsc451hw1;

public class CMSC451hw1 {

    //precondition: n>0
    public static int pent(int n) {
        if (n == 1) {
            return 1;
        } else {
            return (pent(n - 1) + 3 * n - 2);
        }
    }
    //postcondtition: returns (3n^2-n)/2

    public static void main(String[] args) {
        System.out.println(pentagonal(62));
        System.out.println("----------------------------------------------");
        System.out.println(pent(6));

    }

    public static int pentagonal(int n) {
        int result = 0;
        for (int i = 1; i <= n; i++) {
            result += 3 * i - 2;
        }
        return result;
    }

}
