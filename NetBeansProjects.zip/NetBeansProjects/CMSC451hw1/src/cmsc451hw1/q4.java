
package cmsc451hw1;


public class q4 {
    public static int count=0;

    public static void main(String[] args) {
        
        int[] array = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
        for ( int i=0;i<array.length;i++){
        System.out.println(recursiveBinarySearch(array,array[i],0,array.length-1)+" count: "+count);
        if(count>5){System.out.println("ALERT-----------------");}
        count=0;
        }
    }

   private static int recursiveBinarySearch(int[] array, int target, int left, int right) {
      count++;
       System.out.println("L: "+left+" R: "+right);
        if (left > right) {
            return -1;
        }
        int middle = (left + right) / 2;
        if (array[middle] == target) {
            return middle;
        }
        if (array[middle] > target) {
            return recursiveBinarySearch(array, target, left, middle - 1);
        }
        return recursiveBinarySearch(array, target, middle + 1, right);
    }
   

}
