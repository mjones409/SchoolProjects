
package cmsc451hw1;

public class q3 {
    public static void main(String[] args) {

        double[] coefficients = {5,5,5,5,5,8,4,7,2,3.2,4.1,5.2};
        System.out.println(evaluate(coefficients,4));
    }

private static double evaluate(double[] coefficients, double x) 
{ 
double result = coefficients[0]; 
double power = 1; 
for (int i = 1; i < coefficients.length; i++) 
{ 
power = power * x; 
result = result + coefficients[i] * power; 
System.out.println(i);
} 
return result; 
}
}