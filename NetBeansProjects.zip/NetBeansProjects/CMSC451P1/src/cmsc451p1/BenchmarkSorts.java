/*
 * File: BenchmarkSorts.java
 * Author: Marcus Jones
 * Date: 16 November 2019
 * Purpose: CMSC 451 Project 1
 */
package cmsc451p1;

import static java.lang.Double.NaN;
import java.text.*;
import java.util.*;
import java.util.stream.*;

public class BenchmarkSorts {

    private static DecimalFormat df = new DecimalFormat("#.###");
    private static int[] list;
    private static double[][] recCountResults = new double[10][50];
    private static double[][] itCountResults = new double[10][50];
    private static long endTimer = System.currentTimeMillis();
    private static long startTimer = System.currentTimeMillis();
    private static double[][] recTimeResults = new double[10][50];
    private static double[][] itTimeResults = new double[10][50];
    private static int[] sizes;

    BenchmarkSorts(int[] sizes) {
        this.sizes = sizes;
        Random rand = new Random();//random object
        //iterates through sizes to call sort methods on each size
        for (int i = 0; i < sizes.length; i++) {
            //makes list the correct sizes
            list = new int[sizes[i]];
            //creates 50 test cases
            for (int j = 0; j < 50; j++) {
                /*fills list with random ints from negative 
             100 (inclusive)to 100(exclusive)*/
                list = rand.ints(sizes[i], -100, 100).toArray();
                runSorts(i, j);
            }
        }
        displayReport();
    }

    public void runSorts(int r, int c) {
        //new InsertionSort object
        InsertionSort inSort = new InsertionSort();
        //temporary array to hold contents of list between sorts
        int[] temp = new int[list.length];

        //copy list to temp
        System.arraycopy(list, 0, temp, 0, temp.length);

        //recursive
        startTimer = inSort.getTime();//starts timer
        list = inSort.recursiveSort(list, 1, 1);//recursive sort
        endTimer = inSort.getTime();//ends timer
        try {
            inSort.checkList(list);//checks order of list
        } catch (UnsortedException ue) {
        }
        recCountResults[r][c] = inSort.getCount();//adds count result to array
        recTimeResults[r][c] = endTimer - startTimer;//adds time result to array

        //copy temp to list
        System.arraycopy(temp, 0, list, 0, list.length);

        //iterative
        startTimer = inSort.getTime();//starts timer
        list = inSort.iterativeSort(list);//iterative sort
        endTimer = inSort.getTime();//ends timer
        try {
            inSort.checkList(list);//checks order of list
        } catch (UnsortedException ue) {
        }

        itCountResults[r][c] = inSort.getCount();
        itTimeResults[r][c] = endTimer - startTimer;//adds time result to array
    }

    /*SCREENSHOT OF TABLE IN REQUIRED FORMAT PROVIDED IN ZIP FILE*/
    public void displayReport() {
        double countAv;
        double countSD = 0;
        double timeAv;
        double timeSD = 0;
        int caseNum;
        //recursive results
        for (int i = 0; i < 10; i++) {
            caseNum = i + 1;
            countAv = DoubleStream.of(recCountResults[i]).average().getAsDouble();
            timeAv = DoubleStream.of(recTimeResults[i]).average().getAsDouble();
            for (int j = 0; j < 50; j++) {
                countSD = countSD + ((recCountResults[i][j] - countAv) * (recCountResults[i][j] - countAv));
                countSD = Double.parseDouble(df.format(countSD));
                timeSD = timeSD + ((recTimeResults[i][j] - timeAv) * (recTimeResults[i][j] - timeAv));
                timeSD = Double.parseDouble(df.format(timeSD));
            }
            countSD = Double.parseDouble(df.format(countSD / 50));
            countSD = Math.sqrt(countSD);
            timeSD = Double.parseDouble(df.format(timeSD / 50));
            timeSD = Math.sqrt(timeSD);
            //ensures no division by zero
            if (timeAv == 0) {
                timeAv = NaN;
            }
            System.out.print("Recursive Case: " + caseNum + " n: " + sizes[i] + " Average Count: " + countAv + " Count CV: " + Double.parseDouble(df.format(countSD / countAv)));
            System.out.println(" Average Time: " + timeAv + " Time CV: " + Double.parseDouble(df.format(timeSD / timeAv)));
        }

        //iterative results
        countSD = 0;
        for (int i = 0; i < 10; i++) {
            caseNum = i + 1;
            countAv = DoubleStream.of(itCountResults[i]).average().getAsDouble();
            timeAv = DoubleStream.of(itTimeResults[i]).average().getAsDouble();
            for (int j = 0; j < 50; j++) {
                countSD = countSD + ((itCountResults[i][j] - countAv) * (itCountResults[i][j] - countAv));
                countSD = Double.parseDouble(df.format(countSD));
                timeSD = timeSD + ((itTimeResults[i][j] - timeAv) * (itTimeResults[i][j] - timeAv));
                timeSD = Double.parseDouble(df.format(timeSD));

            }
            countSD = Double.parseDouble(df.format(countSD / 50));
            countSD = Math.sqrt(countSD);
            timeSD = Double.parseDouble(df.format(timeSD / 50));
            timeSD = Math.sqrt(timeSD);
            //ensures no division by zero
            if (timeAv == 0) {
                timeAv = NaN;
            }
            System.out.print("Iterative Case: " + caseNum + " n: " + sizes[i] + " Average Count: " + countAv + " Count CV: " + Double.parseDouble(df.format(countSD / countAv)));
            System.out.println(" Average Time: " + timeAv + " Time CV: " + Double.parseDouble(df.format(timeSD / timeAv)));
        }

    }
}
