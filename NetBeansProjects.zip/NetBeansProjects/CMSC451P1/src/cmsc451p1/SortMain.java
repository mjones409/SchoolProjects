/*
 * File: SortMain.java
 * Author: Marcus Jones
 * Date: 14 December 2019
 * Purpose: CMSC 451 Project 2
 */
package cmsc451p1;

public class SortMain {

    public static void main(String[] args) {
        //anything over 11500 produced stack overflow from my recursive method
        int[] sizes = new int[]{0, 1, 5, 100, 500, 1000, 5000, 7500, 10000, 11500};

        /*commented code used to warm up the JVM*/
        // for (int i = 0; i < 100; i++) {
        // System.out.println("\n\n\n");
        BenchmarkSorts bench = new BenchmarkSorts(sizes);
        //  }
    }

}
