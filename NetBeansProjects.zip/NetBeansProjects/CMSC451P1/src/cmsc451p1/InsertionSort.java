/*
 * File: InsertionSort.java
 * Author: Marcus Jones
 * Date: 16 November 2019
 * Purpose: CMSC 451 Project 1
 */
package cmsc451p1;

public class InsertionSort implements SortInterface {

    private static long count = 0;

    //recursive insertion sort code created by me
    @Override
    public int[] recursiveSort(int[] list, int x, int i) {

        // Base case 
        if (list.length <= 1 || x == list.length) {
            return list;//called once
        }

        //continually flips list[i] and list[i-1] if list[i] is smaller
        if (i > 0 && list[i] < list[i - 1]) {
            /*this recursive case is the critical 
                operation we are measuring*/
            count++;
            int temp = list[i - 1];
            list[i - 1] = list[i];
            list[i] = temp;
            i--;
            recursiveSort(list, x, i);
        } else {//this case is called n-1 times maximum

            /*moves pointer to the right 1 when
            the pointed to element and everything
            to the left of it is already sorted
            until x can't be shifted anymore*/
            if (x != list.length) {
                x++;
                i = x;
                recursiveSort(list, x, i);
            }
        }

        return list;
    }

    //iterative insertion sort code adapted from psuedocode in the following video: https://www.youtube.com/watch?v=JU767SDMDvA
    @Override
    public int[] iterativeSort(int[] list) {
        for (int i = 1; i < list.length; i++) {
            //for loop called n-1 times maximum
            int j = i;
            while (j != 0 && list[j - 1] > list[j]) {
                /*this while loop is the critical 
                operation we are measuring*/
                count++;
                int temp = list[j - 1];
                list[j - 1] = list[j];
                list[j] = temp;
                j--;
            }
        }

        return list;
    }

    @Override
    public long getCount() {
        long temp = count;
        count = 0;
        return temp;
    }

    @Override
    public long getTime() {
        return System.nanoTime();
    }

    public void checkList(int[] list) throws UnsortedException {
        for (int i = 0; i < list.length - 1; i++) {
            if (list[i] > list[i + 1]) {
                throw new UnsortedException();
            }
        }
    }

}
