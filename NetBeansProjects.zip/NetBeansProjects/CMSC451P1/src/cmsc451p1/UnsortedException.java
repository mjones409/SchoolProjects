/*
 * File: UnsortedException.java
 * Author: Marcus Jones
 * Date: 16 November 2019
 * Purpose: CMSC 451 Project 1
 */
package cmsc451p1;

//custom exception as required by the project guidelines
public class UnsortedException extends Exception {

    UnsortedException() {
        //tells the user that the array isn't sorted
        System.out.println("ERROR! ARRAY IS NOT SORTED");
        System.exit(0);//exits program
    }
}
