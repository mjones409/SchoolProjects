/*
 * File: SortInterface.java
 * Author: Marcus Jones
 * Date: 16 November 2019
 * Purpose: CMSC 451 Project 1
 */
package cmsc451p1;

public interface SortInterface {

    int[] recursiveSort(int[] list, int x, int i);

    int[] iterativeSort(int[] list);

    long getCount();

    long getTime();
}
