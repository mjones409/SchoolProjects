/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example2;

/**
 *
 * @author Chaos
 */
public class Example2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
int num;
num =100;
System.out.println("This is num:"+num);
num=num*2;
System.out.print("The value of num *2 is");
System.out.println(num);

        }
    
}
