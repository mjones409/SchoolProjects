/* 
File: Parser.java
Author: Marcus Jones
Date: 15 September 2019
Purpose: CMSC330 Project 1
 */
package p1recursivedescentparser;

import java.awt.*;
import java.util.*;
import javax.swing.*;

@SuppressWarnings("unchecked")
public class Parser {

    private Scanner sc;
    private JFrame f;
    private JPanel fp = new JPanel();
    private int lc = 1;//keeps track of the line being read

    @SuppressWarnings("unchecked")
    public Parser(Scanner scan) {
        try {
            sc = scan;
            fp = new JPanel();

            while (sc.hasNextLine() && sc.hasNext()) {

                String firstWord = sc.next();

                if (firstWord.equals("Window")) {//first line of the file
                    String token = sc.next();
                    f = new JFrame(token.substring(1, token.length() - 1));
                    String[] dimensionArray = new String[2];
                    token = sc.next();
                    token = token.substring(1, token.length() - 1);
                    dimensionArray[0] = token;
                    token = sc.next();
                    token = token.substring(0, token.length() - 1);
                    dimensionArray[1] = token;
                    f.setSize(Integer.parseInt(dimensionArray[0]), Integer.parseInt(dimensionArray[1]));

                    if (sc.next().equals("Layout")) {
                        fp.setLayout(addLayout());
                    }
                }

                if (firstWord.equals("Panel")) {
                    fp.add(addPanel());
                    f.add(fp);
                }

                if (firstWord.equals("Button")) {
                    fp.add(addButton());
                }
                if (firstWord.equals("Group")) {
                    @SuppressWarnings("unchecked")
                    LinkedList<JRadioButton> groupList = addGroup();
                    while (groupList.isEmpty() == false) {
                        fp.add((Component) groupList.pop());
                    }
                }
                if (firstWord.equals("Label")) {
                    fp.add(addLabel());
                }
                if (firstWord.equals("Textfield")) {
                    fp.add(addTextField());
                }

                f.setVisible(true);
            }

        } catch (Exception syntax) {
            JOptionPane.showMessageDialog(f, "there is an error near line " + lc + " of your file");
        }
    }

    //panel holds the recursion to addPanel
    private JPanel addPanel() {
        lc++;

        JPanel panel = new JPanel();
        String firstWord = sc.next();
        panel.setLayout(addLayout());
        while (firstWord.equals("End;") == false) {
            sc.nextLine();
            firstWord = sc.next();
            if (firstWord.equals("Panel")) {
                panel.add(addPanel());//recursive call
            }

            if (firstWord.equals("Button")) {
                panel.add(addButton());
            }
            if (firstWord.equals("Group")) {
                @SuppressWarnings("unchecked")
                LinkedList<JRadioButton> groupList = addGroup();
                while (groupList.isEmpty() == false) {
                    panel.add((Component) groupList.pop());
                }
            }
            if (firstWord.equals("Label")) {
                panel.add(addLabel());
            }

            if (firstWord.equals("Textfield")) {
                panel.add(addTextField());
            }

        }
        lc++;
        return panel;
    }

    private LayoutManager addLayout() {

        String token = sc.next();
        if (token.equals("Flow:")) {
            return new FlowLayout();
        } else {
            int[] gridArray = new int[4];
            try {
                token = token.substring(5, token.length() - 1);
                gridArray[0] = Integer.parseInt(token);
                token = sc.next();
                token = token.substring(0, token.length() - 1);
                gridArray[1] = Integer.parseInt(token);
                token = sc.next();
                token = token.substring(0, token.length() - 1);
                gridArray[2] = Integer.parseInt(token);
                token = sc.next();
                token = token.substring(0, token.length() - 2);
                gridArray[3] = Integer.parseInt(token);
                return new GridLayout(gridArray[0], gridArray[1], gridArray[2], gridArray[3]);

            } catch (Exception e) {
                try {
                    //in case gridlayout only has 2 arguments
                    token = token.substring(0, token.length() - 1);
                    return new GridLayout(gridArray[0], Integer.parseInt(token));
                } catch (Exception x) {
                    JOptionPane.showMessageDialog(f, "there is an error near line " + lc + " of your file");
                }
                JOptionPane.showMessageDialog(f, "there is an error near line " + lc + " of your file");

            }
        }
        JOptionPane.showMessageDialog(f, "there is an error near line " + lc + " of your file");

        return null;
    }

    private JButton addButton() {
        lc++;

        String token = sc.next();
        token = token.substring(1, token.length() - 2);
        JButton button = new JButton(token);
        return button;
    }

    private LinkedList addGroup() {
        lc++;

        ButtonGroup bg = new ButtonGroup();
        @SuppressWarnings("unchecked")
        LinkedList<JRadioButton> radioList = new LinkedList();
        sc.next();
        String token = sc.next();
        token = token.substring(1, token.length() - 2);
        JRadioButton r1 = new JRadioButton(token);
        bg.add(r1);
        radioList.add(r1);
        sc.nextLine();

        while (sc.next().equals("End;") == false) {
            lc++;

            token = sc.next();
            token = token.substring(1, token.length() - 2);
            JRadioButton rNext = new JRadioButton(token);
            bg.add(rNext);
            radioList.add(rNext);

        }
        return radioList;
    }

    private JLabel addLabel() {
        lc++;

        String token = sc.next();
        token = token.substring(1, token.length() - 2);
        JLabel label = new JLabel(token);
        return label;
    }

    private JTextField addTextField() {
        lc++;

        String token = sc.next();
        token = token.substring(0, token.length() - 1);
        JTextField txtField = new JTextField(Integer.parseInt(token));
        return txtField;
    }

}
