/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1recursivedescentparser;

import java.util.Scanner;


public class CheckMe {
    private Scanner sc;

    public CheckMe(Scanner scan){
        sc=scan;
        firstLine();
    }
    private void firstLine(){
    String wind, name, size1, size2, lay, gridFlow, g2, g3, g4;
    wind=sc.next();
    name=sc.next();
    size1=sc.next();
    size2=sc.next();
    lay=sc.next();
    if(wind.equals("Window")==false){System.out.println("wind error");}
    if(name.charAt(0)!='"'||name.charAt(name.length()-1)!='"'){System.out.println("name error");}
    if(size1.charAt(0)!='('){System.out.println("parenthesis1 eror");}
    if(size1.charAt(size1.length()-1)!=','){System.out.println("comma1 eror");}
    size1=size1.substring(1, size1.length()-1);
    if(Integer.parseInt(size1)==0){System.out.println("DO NOTHING, just a parse int error check");}
    if(size2.charAt(size2.length()-1)!=')'){System.out.println("parenthesis2 eror");}
    size2=size2.substring(0, size1.length()-1);
    if(Integer.parseInt(size2)==0){System.out.println("DO NOTHING, just a parse int error check");}
    if (lay.equals("Layout")==false){System.out.println("lay error");}
    
    boolean isFlow=true;
    gridFlow= sc.next();
    if(gridFlow.substring(0, 5).equals("Grid(")){isFlow=false;System.out.println("gridlayout");}
    else if(gridFlow.equals("Flow:")){isFlow=true;System.out.println("flowlayut");}
    else{System.out.println("ERROR neither grid nor flow");}
    
    if(isFlow==false){
    gridFlow=gridFlow.substring(5,gridFlow.length()-1);
    if(Integer.parseInt(gridFlow)<=0){System.out.println("DO NOTHING, just a parse int error check");}
    g2=sc.next();
    
    boolean gridArgs4=true;
    if(g2.charAt(g2.length()-1)==':'){gridArgs4=false;}
    if (gridArgs4==false){}
    
    
    if (gridArgs4==true){
    if(Integer.parseInt(g2)<=0){System.out.println("DO NOTHING, just a parse int error check");}
    if (Integer.parseInt(gridFlow)<=0&&Integer.parseInt(g2)<=0){System.out.println("grid is too small");}
    
    System.out.println(gridFlow);
    }
    }
    
    }

}
