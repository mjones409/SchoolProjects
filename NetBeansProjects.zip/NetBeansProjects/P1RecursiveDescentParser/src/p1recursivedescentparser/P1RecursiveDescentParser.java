/* 
File: P1RecursiveDescentParser.java
Author: Marcus Jones
Date: 15 September 2019
Purpose: CMSC330 Project 1
 */
package p1recursivedescentparser;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;

public class P1RecursiveDescentParser {

    public static void main(String[] args) {

        JFrame f0 = new JFrame("Recursive Descent P1");

        //creating gui components
        JButton chooseFileButton = new JButton("Choose File From This Folder");
        JTextField filePath = new JTextField(45);//the file path & file name
        filePath.setText("File Path...");
        filePath.setEditable(false);

        //set up filechooser
        JFileChooser fc = new JFileChooser();
        fc.setCurrentDirectory(new java.io.File("."));
        fc.setDialogTitle("Choose Your File");

        //panels are added 
        f0.add(chooseFileButton, BorderLayout.NORTH);
        f0.add(filePath, BorderLayout.CENTER);

        f0.setSize(600, 250);
        f0.setVisible(true);
        f0.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //choose file button action listener
        chooseFileButton.addActionListener((ActionEvent arg1) -> {
            fc.showOpenDialog(chooseFileButton);// opens choosefile

            try {
                //scanner equals the chosen file contents
                Scanner sc = new Scanner(new File(fc.getSelectedFile().getName()));
                //sets the file path in the text box
                filePath.setText(fc.getSelectedFile().getAbsolutePath());
                Parser parse = new Parser(sc);

            } catch (Exception e) {
                JOptionPane.showMessageDialog(f0, "there is an error of type " + e + " with your file");

            }
        });//end choose file button action listener

    }

}
