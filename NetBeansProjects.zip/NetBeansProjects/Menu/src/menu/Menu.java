/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menu;

/**
 *
 * @author Chaos
 */
public class Menu {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws java.io.IOException{
        char choice;
        do{
        System.out.println("Menu");
        
        System.out.println("1. Continue");
        System.out.println("2. New Game");
        System.out.println("3. Settings");
        System.out.println("4. About");
        System.out.println("5. Quit\n");
        
        choice=(char)System.in.read();
        
        }while(choice<'1'||choice>'5');
        
        switch(choice){
        
        case'1':
        System.out.println("*starting from level 99...*");
        break;
        case'2':
        System.out.println("*starting from level 1...*");
        break;
        case'3':
        System.out.println("*choosing controller settings...*");
        break;
        case'4':
        System.out.println("*Marcus Jones studios made this game...*");
        break;
        case'5':
        System.out.println("*BYE...*");
        break;
    }
        }
        
    }
    
    
    
